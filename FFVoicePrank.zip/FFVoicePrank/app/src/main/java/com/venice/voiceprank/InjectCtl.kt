package com.venice.voiceprank

import android.content.Context
import android.net.Uri
import java.io.File

/** অ্যাপের দিক থেকে root ইনজেকশন প্রসেস চালানো ও কমান্ড পাঠানো। */
object InjectCtl {
    @Volatile var active = false

    fun dir(ctx: Context): File =
        File(ctx.applicationContext.filesDir, "inject").apply { mkdirs() }

    fun start(ctx: Context): String {
        val d = dir(ctx)
        File(d, "ready").delete()
        File(d, "cmd").delete()
        File(d, "inject.log").delete()
        RootTools.run("pkill -f com.venice.voiceprank.Injector")
        val apk = ctx.applicationInfo.sourceDir
        RootTools.run(
            "CLASSPATH=$apk nohup app_process /system/bin com.venice.voiceprank.Injector ${d.absolutePath} >/dev/null 2>&1 &"
        )
        for (i in 0 until 40) {
            if (File(d, "ready").exists()) {
                active = true
                return "ইনজেকশন চালু ✅ (এখন সাউন্ড মাইকে যাবে)"
            }
            Thread.sleep(250)
        }
        active = false
        val log = try { File(d, "inject.log").readText().takeLast(1500) } catch (e: Exception) { "(লগ নেই)" }
        return "চালু হয়নি ❌\n$log"
    }

    fun stop(ctx: Context) {
        send(ctx, "quit")
        Thread.sleep(300)
        RootTools.run("pkill -f com.venice.voiceprank.Injector")
        File(dir(ctx), "ready").delete()
        active = false
    }

    fun stopPlayback(ctx: Context) = send(ctx, "stop")

    fun play(ctx: Context, uri: String) {
        val app = ctx.applicationContext
        Thread {
            val d = dir(app)
            val f = File(d, "pcm_" + uri.hashCode() + ".pcm")
            if (!f.exists() && !PcmConverter.convert(app, Uri.parse(uri), f)) return@Thread
            send(app, f.absolutePath)
        }.start()
    }

    private fun send(ctx: Context, text: String) {
        try {
            val d = dir(ctx)
            val tmp = File(d, "cmd.tmp")
            tmp.writeText(text)
            tmp.renameTo(File(d, "cmd"))
        } catch (_: Exception) {}
    }
}
