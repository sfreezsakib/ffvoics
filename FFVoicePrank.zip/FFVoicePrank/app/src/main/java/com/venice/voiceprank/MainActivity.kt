package com.venice.voiceprank

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView

    private val reqPick = 101
    private val reqNotif = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(makeButton("➕ সাউন্ড যোগ করো") { pickSound() })
        root.addView(makeButton("🔊 ভলিউম ম্যাক্স") { maxVolume() })
        root.addView(makeButton("▶ ওভারলে চালু করো") { startOverlay() })
        root.addView(makeButton("⏹ ওভারলে বন্ধ করো") {
            stopService(Intent(this, OverlayService::class.java))
            Player.stop()
        })
        root.addView(makeButton("🔑 Root চেক করো") { checkRoot() })
        root.addView(makeButton("🎙 Root ইনজেকশন চালু (পরীক্ষামূলক)") { startInject() })
        root.addView(makeButton("🎙 Root ইনজেকশন বন্ধ") { stopInject() })
        root.addView(makeButton("🧪 Root ডায়াগনস্টিক রিপোর্ট") { diagnostics() })

        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(listBox) }
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { onClick() }
        return b
    }

    private fun refresh() {
        listBox.removeAllViews()
        val sounds = SoundStore.all(this)
        if (sounds.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "এখনো কোনো সাউন্ড যোগ করা হয়নি।" })
            return
        }
        for (s in sounds) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val play = makeButton("▶ " + s.name) {
                if (!Player.play(this, s.uri)) toast("সাউন্ড চালানো যায়নি")
            }
            row.addView(
                play,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(makeButton("✖") {
                SoundStore.remove(this, s.uri)
                refresh()
            })
            listBox.addView(row)
        }
    }

    private fun pickSound() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, reqPick)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        SoundStore.add(this, uri.toString(), displayName(uri))
        refresh()
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "sound"
    }

    private fun maxVolume() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            0
        )
        toast("ভলিউম ম্যাক্স করা হয়েছে")
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("ওভারলে পারমিশন দাও, তারপর আবার চালু করো")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        toast("ওভারলে চালু হয়েছে")
    }

    private fun checkRoot() {
        status.text = "Root চেক হচ্ছে..."
        Thread {
            val ok = RootTools.hasRoot()
            val inst = if (ok) RootTools.installer() else ""
            runOnUiThread {
                status.text = if (ok) {
                    "Mode: ROOT ✅  (" + (if (inst.isBlank()) "KernelSU/Magisk পাওয়া যায়নি" else inst) + ")"
                } else {
                    "Mode: NON-ROOT (স্পিকার পদ্ধতি) — ওভারলে ও সাউন্ড চলবে"
                }
            }
        }.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun startInject() {
        status.text = "ইনজেকশন চালু হচ্ছে..."
        Thread {
            val msg = if (RootTools.hasRoot()) InjectCtl.start(this) else "Root নেই ❌"
            runOnUiThread { status.text = msg }
        }.start()
    }

    private fun stopInject() {
        Thread {
            InjectCtl.stop(this)
            runOnUiThread { status.text = "ইনজেকশন বন্ধ (এখন স্পিকার পদ্ধতি)" }
        }.start()
    }

    private fun diagnostics() {
        status.text = "ডায়াগনস্টিক চলছে..."
        Thread {
            if (!RootTools.hasRoot()) {
                runOnUiThread { status.text = "Root নেই, তাই ডায়াগনস্টিক চালানো যায়নি" }
                return@Thread
            }
            val cmds = listOf(
                "getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release; getprop ro.board.platform",
                "cat /proc/asound/cards",
                "which tinymix tinyplay tinycap",
                "ls /vendor/etc | grep -i audio",
                "grep -il remote_submix /vendor/etc/*audio*.xml /vendor/etc/audio/*.xml /system/etc/*audio*.xml",
                "magisk -V; ksud --version",
                "dumpsys audio | grep -i -E 'submix|source' | head -30"
            )
            val sb = StringBuilder()
            for (c in cmds) {
                sb.append("### ").append(c).append("\n")
                sb.append(RootTools.run(c).trim()).append("\n\n")
            }
            val report = sb.toString()
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("report", report))
                val tv = TextView(this).apply {
                    text = report
                    textSize = 11f
                    setTextIsSelectable(true)
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                }
                AlertDialog.Builder(this)
                    .setTitle("রিপোর্ট (কপি হয়েছে)")
                    .setView(ScrollView(this).apply { addView(tv) })
                    .setPositiveButton("ঠিক আছে", null)
                    .show()
                status.text = "রিপোর্ট কপি হয়েছে"
            }
        }.start()
    }
}
