package com.venice.voiceprank

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView

    private val reqPick = 101
    private val reqNotif = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(makeButton("➕ সাউন্ড যোগ করো") { pickSound() })
        root.addView(makeButton("🔊 ভলিউম ম্যাক্স") { maxVolume() })
        root.addView(makeButton("▶ ওভারলে চালু করো") { startOverlay() })
        root.addView(makeButton("⏹ ওভারলে বন্ধ করো") {
            stopService(Intent(this, OverlayService::class.java))
            Player.stop()
        })
        root.addView(makeButton("🔑 Root চেক করো") { checkRoot() })

        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(listBox) }
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { onClick() }
        return b
    }

    private fun refresh() {
        listBox.removeAllViews()
        val sounds = SoundStore.all(this)
        if (sounds.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "এখনো কোনো সাউন্ড যোগ করা হয়নি।" })
            return
        }
        for (s in sounds) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val play = makeButton("▶ " + s.name) {
                if (!Player.play(this, s.uri)) toast("সাউন্ড চালানো যায়নি")
            }
            row.addView(
                play,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(makeButton("✖") {
                SoundStore.remove(this, s.uri)
                refresh()
            })
            listBox.addView(row)
        }
    }

    private fun pickSound() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, reqPick)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        SoundStore.add(this, uri.toString(), displayName(uri))
        refresh()
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "sound"
    }

    private fun maxVolume() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            0
        )
        toast("ভলিউম ম্যাক্স করা হয়েছে")
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("ওভারলে পারমিশন দাও, তারপর আবার চালু করো")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        toast("ওভারলে চালু হয়েছে")
    }

    private fun checkRoot() {
        status.text = "Root চেক হচ্ছে..."
        Thread {
            val ok = RootTools.hasRoot()
            val inst = if (ok) RootTools.installer() else ""
            runOnUiThread {
                status.text = if (ok) {
                    "Root: আছে ✅  (" + (if (inst.isBlank()) "KernelSU/Magisk পাওয়া যায়নি" else inst) + ")"
                } else {
                    "Root: নেই ❌ (root ছাড়াও বাকি ফিচার চলবে)"
                }
            }
        }.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
