package com.venice.voiceprank

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri

object Player {
    private var mp: MediaPlayer? = null
    private var appCtx: Context? = null

    fun play(ctx: Context, uri: String): Boolean {
        appCtx = ctx.applicationContext
        if (InjectCtl.active) {
            InjectCtl.play(ctx, uri)
            return true
        }
        appCtx = ctx.applicationContext
        stop()
        val m = MediaPlayer()
        mp = m
        return try {
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            m.setDataSource(ctx.applicationContext, Uri.parse(uri))
            m.setOnCompletionListener { Player.stop() }
            m.prepare()
            m.start()
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    fun stop() {
        if (InjectCtl.active) InjectCtl.stopPlayback(appCtx ?: return)
        val m = mp ?: return
        mp = null
        try { m.stop() } catch (_: Exception) {}
        try { m.release() } catch (_: Exception) {}
    }
}
