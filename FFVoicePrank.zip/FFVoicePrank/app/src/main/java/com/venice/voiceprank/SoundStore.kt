package com.venice.voiceprank

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Sound(val uri: String, val name: String)

object SoundStore {
    private const val PREFS = "sounds"
    private const val KEY = "items"

    fun all(ctx: Context): MutableList<Sound> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<Sound>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Sound(o.getString("uri"), o.getString("name")))
        }
        return out
    }

    fun add(ctx: Context, uri: String, name: String) {
        val list = all(ctx)
        list.add(Sound(uri, name))
        save(ctx, list)
    }

    fun remove(ctx: Context, uri: String) {
        save(ctx, all(ctx).filterNot { it.uri == uri })
    }

    private fun save(ctx: Context, list: List<Sound>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }
}
