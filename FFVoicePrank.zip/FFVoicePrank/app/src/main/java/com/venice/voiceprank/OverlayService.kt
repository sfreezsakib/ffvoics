package com.venice.voiceprank

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.ServiceCompat
import kotlin.math.abs

class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var panel: View? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("FF Voice Prank")
            .setContentText("ওভারলে চালু আছে")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    private fun newParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun addBubble() {
        val size = dp(56)
        val b = TextView(this).apply {
            text = "🎤"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDDE53935.toInt())
            }
        }
        bubbleLp = newParams(size, size).apply { x = 0; y = dp(200) }

        b.setOnTouchListener(object : View.OnTouchListener {
            var ix = 0
            var iy = 0
            var tx = 0f
            var ty = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ix = bubbleLp.x; iy = bubbleLp.y
                        tx = e.rawX; ty = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            bubbleLp.x = ix + dx
                            bubbleLp.y = iy + dy
                            wm?.updateViewLayout(v, bubbleLp)
                            panel?.let {
                                panelLp.x = bubbleLp.x
                                panelLp.y = bubbleLp.y + dp(60)
                                wm?.updateViewLayout(it, panelLp)
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })

        bubble = b
        wm?.addView(b, bubbleLp)
    }

    private fun togglePanel() {
        val existing = panel
        if (existing != null) {
            wm?.removeView(existing)
            panel = null
            return
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xEE222222.toInt())
            }
        }

        val sounds = SoundStore.all(this)
        if (sounds.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "কোনো সাউন্ড নেই"
                setTextColor(Color.WHITE)
            })
        }
        for (s in sounds) {
            box.addView(Button(this).apply {
                text = s.name
                isAllCaps = false
                setOnClickListener { Player.play(this@OverlayService, s.uri) }
            })
        }
        box.addView(Button(this).apply {
            text = "⏹ থামাও"
            setOnClickListener { Player.stop() }
        })
        box.addView(Button(this).apply {
            text = "✖ ওভারলে বন্ধ"
            setOnClickListener { stopSelf() }
        })

        val scroll = ScrollView(this).apply { addView(box) }
        val h = if (sounds.size > 4) dp(340) else ViewGroup.LayoutParams.WRAP_CONTENT
        panelLp = newParams(dp(220), h).apply {
            x = bubbleLp.x
            y = bubbleLp.y + dp(60)
        }
        panel = scroll
        wm?.addView(scroll, panelLp)
    }

    override fun onDestroy() {
        try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        panel = null
        bubble = null
        Player.stop()
        super.onDestroy()
    }
}
