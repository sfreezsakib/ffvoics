package com.issakib.isffvoice

object RootTools {

    fun hasRoot(): Boolean = run("id").contains("uid=0")

    fun run(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        "root নেই: ${e.message}"
    }

    fun installer(): String =
        if (run("which ksud").isNotBlank()) "ksud module install"
        else if (run("which magisk").isNotBlank()) "magisk --install-module"
        else ""

    fun installModule(zipPath: String): String {
        val i = installer()
        return if (i.isBlank()) "KernelSU/Magisk পাওয়া যায়নি" else run("$i $zipPath")
    }

    fun volumeMax(stream: Int = 3): String =
        run("cmd media_session volume --stream $stream --set 15")

    fun killBackground(): String = run("am kill-all")

    fun whitelist(pkg: String): String =
        run("dumpsys deviceidle whitelist +$pkg")
}
