package com.issakib.isffvoice

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Cartesia.ai টেক্সট-টু-স্পিচ (ক্লোন ভয়েস ID দিয়ে) */
object Tts {
    data class Cfg(val key: String, val voice: String, val model: String, val lang: String, val ver: String)

    data class VoiceProfile(val name: String, val id: String)

    @Volatile var lastFile: File? = null
    @Volatile var lastText: String = ""

    private fun p(ctx: Context) = ctx.getSharedPreferences("tts", Context.MODE_PRIVATE)

    fun cfg(ctx: Context): Cfg {
        val s = p(ctx)
        return Cfg(
            s.getString("key", "")!!.trim(),
            selected(ctx)?.id ?: "",
            s.getString("model", "sonic-3.6")!!.trim().ifEmpty { "sonic-3.6" },
            s.getString("lang", "bn")!!.trim(),
            s.getString("ver", "2026-08-14")!!.trim().ifEmpty { "2026-08-14" }
        )
    }

    fun save(ctx: Context, c: Cfg) {
        p(ctx).edit().putString("key", c.key.trim())
            .putString("model", c.model.trim()).putString("lang", c.lang.trim())
            .putString("ver", c.ver.trim()).apply()
    }

    // ---------- সেভ করা ক্লোন ভয়েস লিস্ট (নাম + Voice ID) ----------
    @Synchronized
    fun voices(ctx: Context): MutableList<VoiceProfile> {
        val s = p(ctx)
        val out = mutableListOf<VoiceProfile>()
        try {
            val arr = JSONArray(s.getString("voices", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(VoiceProfile(o.getString("name"), o.getString("id")))
            }
        } catch (_: Exception) {}
        // আগের ভার্সনে সেভ করা একক Voice ID থাকলে লিস্টে তুলে নাও
        val legacy = s.getString("voice", "")?.trim() ?: ""
        if (out.isEmpty() && legacy.isNotEmpty()) {
            out.add(VoiceProfile("ভয়েস ১", legacy))
            saveVoices(ctx, out)
            s.edit().remove("voice").putString("sel", legacy).apply()
        }
        return out
    }

    private fun saveVoices(ctx: Context, list: List<VoiceProfile>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("id", it.id)) }
        p(ctx).edit().putString("voices", arr.toString()).apply()
    }

    @Synchronized
    fun addVoice(ctx: Context, name: String, id: String): Boolean {
        val vid = id.trim()
        if (vid.isEmpty()) return false
        val list = voices(ctx)
        if (list.any { it.id == vid }) return false
        val nm = name.trim().ifEmpty { "ভয়েস " + (list.size + 1) }
        list.add(VoiceProfile(nm, vid))
        saveVoices(ctx, list)
        if (selected(ctx) == null || list.size == 1) select(ctx, vid)
        return true
    }

    @Synchronized
    fun removeVoice(ctx: Context, id: String) {
        saveVoices(ctx, voices(ctx).filterNot { it.id == id })
        if (p(ctx).getString("sel", "") == id) p(ctx).edit().remove("sel").apply()
    }

    fun select(ctx: Context, id: String) {
        p(ctx).edit().putString("sel", id).apply()
    }

    /** সিলেক্ট করা ভয়েস; না থাকলে লিস্টের প্রথমটা */
    fun selected(ctx: Context): VoiceProfile? {
        val list = voices(ctx)
        val sel = p(ctx).getString("sel", "") ?: ""
        return list.firstOrNull { it.id == sel } ?: list.firstOrNull()
    }

    fun ready(ctx: Context): Boolean {
        val c = cfg(ctx)
        return c.key.isNotEmpty() && c.voice.isNotEmpty()
    }

    /** done মেইন থ্রেডে ডাকা হয়; null মানে সফল (ভয়েস বাজা শুরু হয়েছে), নাহলে এরর মেসেজ */
    fun speak(ctx: Context, text: String, done: (String?) -> Unit) {
        val app = ctx.applicationContext
        val t = text.trim()
        val main = Handler(Looper.getMainLooper())
        if (t.isEmpty()) { done("আগে কিছু লেখো"); return }
        if (!ready(app)) { done("আগে অ্যাপের ⚙ সেটিংসে API Key দাও ও 🎭 ভয়েস যোগ করো"); return }
        val c = cfg(app)
        Thread {
            var file: File? = null
            var err: String? = null
            try {
                val body = JSONObject()
                    .put("model_id", c.model)
                    .put("transcript", t)
                    .put("voice", JSONObject().put("id", c.voice))
                    .put(
                        "output_format",
                        JSONObject().put("container", "wav").put("encoding", "pcm_s16le").put("sample_rate", 44100)
                    )
                if (c.lang.isNotEmpty()) body.put("language", c.lang)

                val conn = URL("https://api.cartesia.ai/tts/bytes").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Authorization", "Bearer " + c.key)
                conn.setRequestProperty("Cartesia-Version", c.ver)
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                if (code in 200..299) {
                    val dir = File(app.filesDir, "tts").apply { mkdirs() }
                    val f = File(dir, "tts_" + System.currentTimeMillis() + ".wav")
                    conn.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    if (f.length() > 44) file = f else { f.delete(); err = "খালি অডিও এসেছে" }
                } else {
                    val msg = try { conn.errorStream?.bufferedReader()?.readText()?.take(220) ?: "" } catch (e: Exception) { "" }
                    err = "Cartesia এরর $code: $msg"
                }
                conn.disconnect()
            } catch (e: Exception) {
                err = "নেটওয়ার্ক সমস্যা: " + e.message
            }
            val f = file
            val e = err
            main.post {
                if (f != null) {
                    lastFile = f
                    lastText = t
                    cleanup(app, f)
                    if (Player.play(app, Uri.fromFile(f).toString())) done(null) else done("প্লে করা যায়নি")
                } else {
                    done(e ?: "অজানা সমস্যা")
                }
            }
        }.start()
    }

    private fun cleanup(ctx: Context, keep: File) {
        try {
            val files = File(ctx.filesDir, "tts").listFiles()?.sortedByDescending { it.lastModified() } ?: return
            for (f in files.drop(6)) {
                if (f == keep) continue
                File(InjectCtl.dir(ctx), "pcm_" + Uri.fromFile(f).toString().hashCode() + ".pcm").delete()
                f.delete()
            }
        } catch (_: Exception) {}
    }
}
