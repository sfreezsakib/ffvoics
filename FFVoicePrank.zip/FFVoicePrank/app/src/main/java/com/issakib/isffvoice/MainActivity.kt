package com.issakib.isffvoice

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var grid: LinearLayout
    private lateinit var status: TextView
    private lateinit var overlayBtn: TextView
    private lateinit var countText: TextView
    private lateinit var volSeek: SeekBar
    private val cards = HashMap<String, SoundCard>()
    private val anims = mutableListOf<ValueAnimator>()
    private var query = ""
    private val ui = Handler(Looper.getMainLooper())

    private val reqAudio = 101
    private val reqNotif = 102
    private val reqVideo = 103
    private val reqImage = 104

    // এডিটর ডায়ালগের অবস্থা
    private var edDialog: Dialog? = null
    private var edSound: Sound? = null
    private var edPending: String? = null   // null = অপরিবর্তিত, "" = ছবি সরানো
    private var edSaved = false
    private var edPreviewImg: ImageView? = null
    private var edPreviewTxt: TextView? = null

    private val playListener: (String?) -> Unit = { cur ->
        for ((u, c) in cards) c.setPlaying(u == cur)
    }
    private val overlayListener: (Boolean) -> Unit = { updateOverlayBtn() }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun am() = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(14)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(16), pad, dp(24))
        }

        // ---------- হেডার ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            Ui.clipRound(this, dp(18).toFloat())
        }
        val logoBox = FrameLayout(this).apply {
            background = Ui.rect(Ui.BG0, dp(20), Ui.CYAN, dp(2))
            setPadding(dp(3), dp(3), dp(3), dp(3))
            addView(logo, FrameLayout.LayoutParams(dp(64), dp(64)))
        }
        header.addView(logoBox, LinearLayout.LayoutParams(dp(72), dp(72)))
        anims.add(Ui.pulse(logoBox, 1f, 1.06f, 1100))

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        val title = TextView(this).apply {
            text = "IS FF VOICE"
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC)
            setTextColor(Ui.CYAN)
        }
        anims.add(Ui.neonTitle(title))
        titles.addView(title)
        titles.addView(TextView(this).apply {
            text = "👑 Gaming Voice Soundboard"
            textSize = 12f
            setTextColor(Ui.MUTED)
        })
        header.addView(titles)
        content.addView(header)

        // ---------- মূল কন্ট্রোল ----------
        overlayBtn = Ui.button(this, "", Ui.GREEN, Ui.CYAN, 16f) { toggleOverlay() }
        content.addView(overlayBtn, Ui.lp(-1, -2).apply { topMargin = dp(16) })

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(
            Ui.button(this, "🔊 ভলিউম ম্যাক্স", Ui.PURPLE, 0xFF5B3BFF.toInt(), 13f) { maxVolume() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) }
        )
        row2.addView(
            Ui.button(this, "⏹ সব থামাও", Ui.RED, 0xFFB5173A.toInt(), 13f) { Player.stop() },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        content.addView(row2, Ui.lp(-1, -2).apply { topMargin = dp(10) })

        // ভলিউম স্লাইডার
        val volRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(4), 0)
        }
        volRow.addView(TextView(this).apply { text = "🔈"; textSize = 16f })
        volSeek = SeekBar(this).apply {
            max = am().getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            progress = am().getStreamVolume(AudioManager.STREAM_MUSIC)
            progressTintList = ColorStateList.valueOf(Ui.CYAN)
            thumbTintList = ColorStateList.valueOf(Ui.CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) am().setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        volRow.addView(volSeek, LinearLayout.LayoutParams(0, -2, 1f))
        volRow.addView(TextView(this).apply { text = "🔊"; textSize = 16f })
        content.addView(volRow)

        // ---------- ভয়েস সেকশন ----------
        val secRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        countText = TextView(this).apply {
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        secRow.addView(countText, LinearLayout.LayoutParams(0, -2, 1f))
        secRow.addView(Ui.button(this, "➕ ভয়েস যোগ", Ui.CYAN, Ui.PURPLE, 13f) { showAddChooser() })
        content.addView(secRow, Ui.lp(-1, -2).apply { topMargin = dp(20) })

        content.addView(TextView(this).apply {
            text = "কার্ডে ট্যাপ করলে বাজবে, আবার ট্যাপ করলে থামবে • চেপে ধরলে এডিট/ডিলিট"
            textSize = 11f
            setTextColor(Ui.MUTED)
            setPadding(0, dp(4), 0, dp(8))
        })

        val search = EditText(this).apply {
            hint = "🔍 ভয়েস খোঁজো..."
            setHintTextColor(Ui.MUTED)
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine()
            background = Ui.rect(0xFF0A1448.toInt(), dp(14), 0x663A55C0, dp(1))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString()?.trim() ?: ""
                    rebuild(false)
                }
            })
        }
        content.addView(search, Ui.lp(-1, -2).apply { bottomMargin = dp(12) })

        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(grid)

        // ---------- Root / উন্নত ----------
        val rootBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        rootBox.addView(rootBtn("🔑 Root চেক করো") { checkRoot() })
        rootBox.addView(rootBtn("🎙 Root ইনজেকশন চালু (পরীক্ষামূলক)") { startInject() })
        rootBox.addView(rootBtn("🎙 Root ইনজেকশন বন্ধ") { stopInject() })
        rootBox.addView(rootBtn("🧪 Root ডায়াগনস্টিক রিপোর্ট") { diagnostics() })
        status = TextView(this).apply {
            setTextColor(Ui.MUTED)
            textSize = 12f
            setPadding(dp(4), dp(8), dp(4), 0)
        }
        rootBox.addView(status)

        val rootToggle = TextView(this).apply {
            text = "⚙ Root / উন্নত অপশন  ▼"
            setTextColor(Ui.MUTED)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(14))
            isClickable = true
            setOnClickListener {
                val show = rootBox.visibility != View.VISIBLE
                rootBox.visibility = if (show) View.VISIBLE else View.GONE
                text = if (show) "⚙ Root / উন্নত অপশন  ▲" else "⚙ Root / উন্নত অপশন  ▼"
            }
        }
        content.addView(rootToggle, Ui.lp(-1, -2).apply { topMargin = dp(16) })
        content.addView(rootBox)
        content.addView(TextView(this).apply {
            text = "Made with 💙 by IS SAKIB 👑"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Ui.MUTED)
            setPadding(0, dp(8), 0, 0)
        })

        val scroll = ScrollView(this).apply {
            background = Ui.grad(Ui.BG0, Ui.BG2, 0, android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM)
            isFillViewport = true
            addView(content)
        }
        setContentView(scroll)
        updateOverlayBtn()
        rebuild(true)
    }

    private fun rootBtn(label: String, onClick: () -> Unit): TextView =
        Ui.button(this, label, 0xFF14246B.toInt(), 0xFF1B2F8A.toInt(), 13f, onClick).apply {
            layoutParams = Ui.lp(-1, -2).apply { topMargin = dp(8) }
        }

    override fun onResume() {
        super.onResume()
        Player.addListener(playListener)
        OverlayService.onState = overlayListener
        playListener(Player.current)
        updateOverlayBtn()
        volSeek.progress = am().getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    override fun onPause() {
        Player.removeListener(playListener)
        OverlayService.onState = null
        super.onPause()
    }

    override fun onDestroy() {
        for (a in anims) a.cancel()
        anims.clear()
        super.onDestroy()
    }

    // ---------- কার্ড গ্রিড ----------
    private fun rebuild(animate: Boolean) {
        grid.removeAllViews()
        cards.clear()
        val all = SoundStore.all(this)
        countText.text = "🎧 আমার ভয়েস (${all.size})"
        val list = if (query.isEmpty()) all else all.filter { it.name.contains(query, ignoreCase = true) }

        if (list.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = if (all.isEmpty()) "এখনো কোনো ভয়েস নেই।\n\"➕ ভয়েস যোগ\" চেপে অডিও বা ভিডিও থেকে ভয়েস যোগ করো 🎙"
                else "কিছু পাওয়া যায়নি 😕"
                setTextColor(Ui.MUTED)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, dp(30), 0, dp(30))
            })
            return
        }

        val dm = resources.displayMetrics
        val cols = if (dm.widthPixels / dm.density >= 600f) 3 else 2
        val gap = dp(10)
        val side = (dm.widthPixels - dp(14) * 2 - gap * (cols - 1)) / cols

        var i = 0
        while (i < list.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                val idx = i + c
                if (idx >= list.size) break
                val s = list[idx]
                val card = SoundCard(this, s, side, false)
                card.setOnClickListener {
                    if (!Player.play(this, s.uri)) toast("সাউন্ড চালানো যায়নি")
                }
                card.setOnLongClickListener { showEditor(s); true }
                card.setPlaying(Player.current == s.uri)
                cards[s.uri] = card
                row.addView(card, LinearLayout.LayoutParams(side, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (c < cols - 1) rightMargin = gap
                })
                if (animate) Ui.popIn(card, (idx * 45L).coerceAtMost(500L))
            }
            grid.addView(row, Ui.lp(-1, -2).apply { bottomMargin = gap })
            i += cols
        }
    }

    // ---------- ভয়েস যোগ ----------
    private fun showAddChooser() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(Ui.title(this, "ভয়েস যোগ করো"))
        val d = Ui.dialog(this, c)
        c.addView(
            Ui.button(this, "🎵 অডিও ফাইল থেকে\n(একসাথে অনেকগুলো নেওয়া যাবে)", Ui.CYAN, Ui.PURPLE, 14f) {
                d.dismiss(); pick("audio/*", true, reqAudio)
            }
        )
        c.addView(
            Ui.button(this, "🎬 ভিডিও থেকে ভয়েস বের করো", Ui.PURPLE, 0xFF5B3BFF.toInt(), 14f) {
                d.dismiss(); pick("video/*", true, reqVideo)
            }.apply { layoutParams = Ui.lp(-1, -2).apply { topMargin = dp(10) } }
        )
        c.addView(TextView(this).apply {
            text = "বাতিল"
            setTextColor(Ui.MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
            isClickable = true
            setOnClickListener { d.dismiss() }
        })
        d.show()
    }

    private fun pick(type: String, multiple: Boolean, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = type
            if (multiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            reqAudio, reqVideo -> {
                val uris = mutableListOf<Uri>()
                data.clipData?.let { for (k in 0 until it.itemCount) uris.add(it.getItemAt(k).uri) }
                if (uris.isEmpty()) data.data?.let { uris.add(it) }
                importUris(uris)
            }
            reqImage -> {
                val u = data.data ?: return
                val s = edSound ?: return
                toast("⏳ ছবি যোগ হচ্ছে...")
                Thread {
                    val path = Importer.importImage(this, u, s.id)
                    runOnUiThread {
                        if (path == null) {
                            toast("ছবি যোগ করা যায়নি")
                        } else {
                            val old = edPending
                            if (!old.isNullOrEmpty()) try { File(old).delete() } catch (_: Exception) {}
                            edPending = path
                            updatePreview()
                        }
                    }
                }.start()
            }
        }
    }

    private fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        toast("⏳ ভয়েস যোগ হচ্ছে...")
        Thread {
            val added = mutableListOf<Sound>()
            for (u in uris) {
                val id = SoundStore.newId()
                val f = Importer.importAudio(this, u, id) ?: continue
                val s = Sound(id, Uri.fromFile(f).toString(), Importer.baseName(this, u), "")
                SoundStore.add(this, s)
                added.add(s)
            }
            runOnUiThread {
                rebuild(true)
                when {
                    added.isEmpty() -> toast("ভয়েস যোগ করা যায়নি ❌ (ভিডিওতে অডিও আছে কিনা দেখো)")
                    added.size == 1 -> { toast("✅ যোগ হয়েছে — নাম ও ছবি দাও"); showEditor(added[0]) }
                    else -> toast("✅ ${added.size}টি ভয়েস যোগ হয়েছে (কার্ড চেপে ধরে ছবি/নাম বদলাও)")
                }
            }
        }.start()
    }

    // ---------- এডিটর (নাম + ছবি + ডিলিট) ----------
    private fun updatePreview() {
        val s = edSound ?: return
        val path = edPending ?: s.img
        val bmp = if (path.isNotEmpty()) Ui.bitmap(path) else null
        if (bmp != null) {
            edPreviewImg?.setImageBitmap(bmp)
            edPreviewImg?.visibility = View.VISIBLE
            edPreviewTxt?.visibility = View.GONE
        } else {
            edPreviewImg?.visibility = View.GONE
            edPreviewTxt?.visibility = View.VISIBLE
        }
    }

    private fun showEditor(s: Sound) {
        edSound = s
        edPending = null
        edSaved = false

        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        c.addView(Ui.title(this, "✏ ভয়েস এডিট"))

        val prevImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val prevTxt = TextView(this).apply {
            text = s.name.trim().take(1).uppercase().ifEmpty { "🎙" }
            gravity = Gravity.CENTER
            textSize = 40f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = Ui.grad(Ui.PURPLE, Ui.CYAN, 0, android.graphics.drawable.GradientDrawable.Orientation.TL_BR)
        }
        edPreviewImg = prevImg
        edPreviewTxt = prevTxt
        val prev = FrameLayout(this).apply {
            Ui.clipRound(this, dp(20).toFloat())
            addView(prevImg, FrameLayout.LayoutParams(-1, -1))
            addView(prevTxt, FrameLayout.LayoutParams(-1, -1))
            isClickable = true
            setOnClickListener { pick("image/*", false, reqImage) }
        }
        c.addView(prev, LinearLayout.LayoutParams(dp(120), dp(120)))
        updatePreview()

        val imgRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        imgRow.addView(Ui.button(this, "📷 ছবি বাছাই", 0xFF14246B.toInt(), 0xFF1B2F8A.toInt(), 12f) {
            pick("image/*", false, reqImage)
        })
        imgRow.addView(Ui.button(this, "✖ ছবি সরাও", 0xFF14246B.toInt(), 0xFF1B2F8A.toInt(), 12f) {
            val old = edPending
            if (!old.isNullOrEmpty()) try { File(old).delete() } catch (_: Exception) {}
            edPending = ""
            updatePreview()
        }.apply { layoutParams = Ui.lp(-2, -2).apply { leftMargin = dp(8) } })
        c.addView(imgRow, Ui.lp(-2, -2).apply { topMargin = dp(10) })

        val nameEt = EditText(this).apply {
            setText(s.name)
            setTextColor(Color.WHITE)
            setHintTextColor(Ui.MUTED)
            hint = "ভয়েসের নাম"
            textSize = 15f
            setSingleLine()
            background = Ui.rect(0xFF0A1448.toInt(), dp(14), Ui.CYAN, dp(1))
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        c.addView(nameEt, Ui.lp(-1, -2).apply { topMargin = dp(14) })

        val d = Ui.dialog(this, c)
        edDialog = d
        d.setOnDismissListener {
            if (!edSaved) {
                val p = edPending
                if (!p.isNullOrEmpty()) try { File(p).delete() } catch (_: Exception) {}
            }
            edDialog = null
            edPreviewImg = null
            edPreviewTxt = null
        }

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(
            Ui.button(this, "💾 সেভ", Ui.GREEN, Ui.CYAN, 14f) {
                val nm = nameEt.text.toString().trim().ifEmpty { s.name }
                val newImg = edPending ?: s.img
                if (edPending != null && s.img.isNotEmpty() && s.img != newImg) {
                    try { File(s.img).delete() } catch (_: Exception) {}
                }
                SoundStore.update(this, s.id, nm, newImg)
                edSaved = true
                d.dismiss()
                rebuild(false)
            },
            LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) }
        )
        btns.addView(
            Ui.button(this, "🗑 মুছো", Ui.RED, 0xFFB5173A.toInt(), 14f) {
                AlertDialog.Builder(this)
                    .setTitle("\"${s.name}\" মুছবে?")
                    .setPositiveButton("হ্যাঁ, মুছো") { _, _ ->
                        if (Player.current == s.uri) Player.stop()
                        SoundStore.remove(this, s.id)
                        d.dismiss()
                        rebuild(false)
                    }
                    .setNegativeButton("না", null)
                    .show()
            },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        c.addView(btns, Ui.lp(-1, -2).apply { topMargin = dp(16) })
        c.addView(TextView(this).apply {
            text = "বাতিল"
            setTextColor(Ui.MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
            isClickable = true
            setOnClickListener { d.dismiss() }
        })
        d.show()
    }

    // ---------- ওভারলে ----------
    private fun updateOverlayBtn() {
        if (!::overlayBtn.isInitialized) return
        val on = OverlayService.running
        overlayBtn.text = if (on) "⏹  ওভারলে বন্ধ করো" else "🎮  ওভারলে চালু করো"
        overlayBtn.background =
            if (on) Ui.grad(Ui.RED, 0xFFB5173A.toInt(), dp(16)) else Ui.grad(Ui.GREEN, Ui.CYAN, dp(16))
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            Player.stop()
            ui.postDelayed({ updateOverlayBtn() }, 300)
        } else {
            startOverlay()
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("ওভারলে পারমিশন দাও, তারপর আবার চালু করো")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        toast("ওভারলে চালু হয়েছে — অন্য অ্যাপে গিয়ে 🎤 বাবলে চাপো")
        ui.postDelayed({ updateOverlayBtn() }, 500)
    }

    private fun maxVolume() {
        val a = am()
        a.setStreamVolume(AudioManager.STREAM_MUSIC, a.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
        volSeek.progress = volSeek.max
        toast("ভলিউম ম্যাক্স করা হয়েছে")
    }

    // ---------- Root ----------
    private fun checkRoot() {
        status.text = "Root চেক হচ্ছে..."
        Thread {
            val ok = RootTools.hasRoot()
            val inst = if (ok) RootTools.installer() else ""
            runOnUiThread {
                status.text = if (ok) {
                    "Mode: ROOT ✅  (" + (if (inst.isBlank()) "KernelSU/Magisk পাওয়া যায়নি" else inst) + ")"
                } else {
                    "Mode: NON-ROOT (স্পিকার পদ্ধতি) — ওভারলে ও সাউন্ড চলবে"
                }
            }
        }.start()
    }

    private fun startInject() {
        status.text = "ইনজেকশন চালু হচ্ছে..."
        Thread {
            val msg = if (RootTools.hasRoot()) InjectCtl.start(this) else "Root নেই ❌"
            runOnUiThread { status.text = msg }
        }.start()
    }

    private fun stopInject() {
        Thread {
            InjectCtl.stop(this)
            runOnUiThread { status.text = "ইনজেকশন বন্ধ (এখন স্পিকার পদ্ধতি)" }
        }.start()
    }

    private fun diagnostics() {
        status.text = "ডায়াগনস্টিক চলছে..."
        Thread {
            if (!RootTools.hasRoot()) {
                runOnUiThread { status.text = "Root নেই, তাই ডায়াগনস্টিক চালানো যায়নি" }
                return@Thread
            }
            val cmds = listOf(
                "getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release; getprop ro.board.platform",
                "cat /proc/asound/cards",
                "which tinymix tinyplay tinycap",
                "ls /vendor/etc | grep -i audio",
                "grep -il remote_submix /vendor/etc/*audio*.xml /vendor/etc/audio/*.xml /system/etc/*audio*.xml",
                "magisk -V; ksud --version",
                "dumpsys audio | grep -i -E 'submix|source' | head -30"
            )
            val sb = StringBuilder()
            for (c in cmds) {
                sb.append("### ").append(c).append("\n")
                sb.append(RootTools.run(c).trim()).append("\n\n")
            }
            val report = sb.toString()
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("report", report))
                val tv = TextView(this).apply {
                    text = report
                    textSize = 11f
                    setTextIsSelectable(true)
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                }
                AlertDialog.Builder(this)
                    .setTitle("রিপোর্ট (কপি হয়েছে)")
                    .setView(ScrollView(this).apply { addView(tv) })
                    .setPositiveButton("ঠিক আছে", null)
                    .show()
                status.text = "রিপোর্ট কপি হয়েছে"
            }
        }.start()
    }
}
