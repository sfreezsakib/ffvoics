package com.issakib.isffvoice

import android.content.Context
import android.net.Uri
import java.io.File

/** অ্যাপের দিক থেকে root ইনজেকশন প্রসেস চালানো ও কমান্ড পাঠানো। */
object InjectCtl {
    @Volatile var active = false

    /** অ্যাপ আর shell/root প্রসেস দুজনেই পড়তে-লিখতে পারে এমন ফোল্ডার (external app-dir) */
    fun dir(ctx: Context): File {
        val app = ctx.applicationContext
        val base = app.getExternalFilesDir("inject")
        val d = base ?: File(app.filesDir, "inject")
        d.mkdirs()
        return d
    }

    fun start(ctx: Context): String {
        val reason = arrayOf("")
        val m = ShellRunner.pick(ctx, reason)
        if (m == null) { active = false; return reason[0] }
        ShellRunner.mode = m
        val d = dir(ctx)
        File(d, "ready").delete()
        File(d, "cmd").delete()
        File(d, "inject.log").delete()
        ShellRunner.exec("pkill -f com.issakib.isffvoice.Injector")
        val apk = ctx.applicationInfo.sourceDir
        ShellRunner.exec(
            "CLASSPATH=$apk nohup app_process /system/bin com.issakib.isffvoice.Injector ${d.absolutePath} >/dev/null 2>&1 &"
        )
        for (i in 0 until 40) {
            if (File(d, "ready").exists()) {
                active = true
                return "ইনজেকশন চালু ✅ (" + (if (m == ShellRunner.Mode.SHIZUKU) "Shizuku" else "Root") + " মোড — সাউন্ড এখন মাইকে যাবে)"
            }
            Thread.sleep(250)
        }
        active = false
        val log = try { File(d, "inject.log").readText().takeLast(1500) } catch (e: Exception) { "(লগ নেই)" }
        return "চালু হয়নি ❌ (" + (if (m == ShellRunner.Mode.SHIZUKU) "Shizuku" else "Root") + ")\n$log"
    }

    fun stop(ctx: Context) {
        send(ctx, "quit")
        Thread.sleep(300)
        ShellRunner.exec("pkill -f com.issakib.isffvoice.Injector")
        File(dir(ctx), "ready").delete()
        active = false
        ShellRunner.mode = ShellRunner.Mode.NONE
    }

    fun stopPlayback(ctx: Context) = send(ctx, "stop")

    fun play(ctx: Context, uri: String) {
        val app = ctx.applicationContext
        Thread {
            val d = dir(app)
            val f = File(d, "pcm_" + uri.hashCode() + ".pcm")
            if (!f.exists() && !PcmConverter.convert(app, Uri.parse(uri), f)) return@Thread
            send(app, f.absolutePath)
        }.start()
    }

    private fun send(ctx: Context, text: String) {
        try {
            val d = dir(ctx)
            val tmp = File(d, "cmd.tmp")
            tmp.writeText(text)
            tmp.renameTo(File(d, "cmd"))
        } catch (_: Exception) {}
    }
}
