package com.issakib.isffvoice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Looper
import java.io.File
import java.io.FileInputStream
import java.lang.reflect.InvocationTargetException

/**
 * root প্রসেস হিসেবে চলে (app_process দিয়ে)।
 * Android 13+ এর AudioMix MIX_ROLE_INJECTOR ব্যবহার করে মাইকের ক্যাপচারে সাউন্ড ঢোকায়।
 * সব hidden API reflection দিয়ে ডাকা হয়েছে।
 */
object Injector {
    private const val RATE = 48000
    private val I: Class<*> = Int::class.javaPrimitiveType!!
    private lateinit var dir: File

    private fun log(s: String) {
        try {
            val f = File(dir, "inject.log")
            f.appendText(s + "\n")
            f.setReadable(true, false)
        } catch (_: Exception) {}
    }

    private fun unwrap(e: Throwable): Throwable =
        (e as? InvocationTargetException)?.cause ?: e

    @JvmStatic
    fun main(args: Array<String>) {
        dir = File(args[0])
        try {
            log("start uid=" + android.os.Process.myUid())
            Looper.prepareMainLooper()

            val atC = Class.forName("android.app.ActivityThread")
            val thread = atC.getMethod("systemMain").invoke(null)
            val ctx = atC.getMethod("getSystemContext").invoke(thread) as Context
            log("context ok")

            val ruleC = Class.forName("android.media.audiopolicy.AudioMixingRule")
            val rbC = Class.forName("android.media.audiopolicy.AudioMixingRule\$Builder")
            val rb = rbC.getConstructor().newInstance()
            rbC.getMethod("setTargetMixRole", I).invoke(rb, 1) // MIX_ROLE_INJECTOR
            val capPreset = ruleC.getField("RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET").getInt(null)
            val addRule = rbC.getMethod("addMixRule", I, Any::class.java)
            val setPreset = AudioAttributes.Builder::class.java.getMethod("setCapturePreset", I)
            for (p in intArrayOf(1, 5, 6, 7, 9)) { // MIC, CAMCORDER, VOICE_RECOGNITION, VOICE_COMMUNICATION, UNPROCESSED
                val b = AudioAttributes.Builder()
                setPreset.invoke(b, p)
                addRule.invoke(rb, capPreset, b.build())
            }
            val rule = rbC.getMethod("build").invoke(rb)
            log("rule ok")

            val mixC = Class.forName("android.media.audiopolicy.AudioMix")
            val mbC = Class.forName("android.media.audiopolicy.AudioMix\$Builder")
            val mb = mbC.getConstructor(ruleC).newInstance(rule)
            val fmt = AudioFormat.Builder()
                .setSampleRate(RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            mbC.getMethod("setFormat", AudioFormat::class.java).invoke(mb, fmt)
            mbC.getMethod("setRouteFlags", I).invoke(mb, mixC.getField("ROUTE_FLAG_LOOP_BACK").getInt(null))
            val mix = mbC.getMethod("build").invoke(mb)
            log("mix ok")

            val polC = Class.forName("android.media.audiopolicy.AudioPolicy")
            val pbC = Class.forName("android.media.audiopolicy.AudioPolicy\$Builder")
            val pb = pbC.getConstructor(Context::class.java).newInstance(ctx)
            pbC.getMethod("setLooper", Looper::class.java).invoke(pb, Looper.getMainLooper())
            pbC.getMethod("addMix", mixC).invoke(pb, mix)
            val policy = pbC.getMethod("build").invoke(pb)

            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val res = am.javaClass.getMethod("registerAudioPolicy", polC).invoke(am, policy) as Int
            log("registerAudioPolicy = $res")
            if (res != 0) { log("FAILED register"); return }

            val track = polC.getMethod("createAudioTrackSource", mixC).invoke(policy, mix) as AudioTrack
            track.play()
            log("track ok")

            val ready = File(dir, "ready")
            ready.writeText("1")
            ready.setReadable(true, false)

            Thread { commandLoop(track) }.start()
            Looper.loop()
        } catch (t: Throwable) {
            log("ERROR: " + unwrap(t).stackTraceToString().take(1800))
            System.exit(1)
        }
    }

    private fun commandLoop(track: AudioTrack) {
        val cmdFile = File(dir, "cmd")
        while (true) {
            try {
                if (cmdFile.exists()) {
                    val t = cmdFile.readText().trim()
                    cmdFile.delete()
                    when (t) {
                        "quit" -> { File(dir, "ready").delete(); System.exit(0) }
                        "stop" -> { track.pause(); track.flush(); track.play() }
                        else -> playFile(track, t, cmdFile)
                    }
                } else {
                    Thread.sleep(80)
                }
            } catch (t: Throwable) {
                log("loop error: " + t)
                Thread.sleep(500)
            }
        }
    }

    private fun playFile(track: AudioTrack, path: String, cmdFile: File) {
        FileInputStream(path).use { ins ->
            val buf = ByteArray(9600)
            while (true) {
                if (cmdFile.exists()) break
                val n = ins.read(buf)
                if (n <= 0) break
                track.write(buf, 0, n)
            }
        }
    }
}
