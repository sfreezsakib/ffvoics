package com.issakib.isffvoice

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** id = ইউনিক আইডি, uri = অ্যাপের ভেতরের সাউন্ড ফাইল, img = কার্ডের ছবির পাথ (খালি হলে ছবি নেই) */
data class Sound(val id: String, val uri: String, val name: String, val img: String)

object SoundStore {
    private const val PREFS = "sounds"
    private const val KEY = "items"
    private var counter = 0

    @Synchronized
    fun newId(): String = "s" + System.currentTimeMillis() + "_" + (counter++)

    fun soundsDir(ctx: Context): File = File(ctx.filesDir, "sounds").apply { mkdirs() }
    fun imagesDir(ctx: Context): File = File(ctx.filesDir, "images").apply { mkdirs() }

    @Synchronized
    fun all(ctx: Context): MutableList<Sound> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<Sound>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                Sound(
                    o.optString("id", o.getString("uri")),
                    o.getString("uri"),
                    o.getString("name"),
                    o.optString("img", "")
                )
            )
        }
        return out
    }

    @Synchronized
    fun add(ctx: Context, s: Sound) {
        val list = all(ctx)
        list.add(s)
        save(ctx, list)
    }

    @Synchronized
    fun update(ctx: Context, id: String, name: String, img: String) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(name = name, img = img) else it })
    }

    @Synchronized
    fun remove(ctx: Context, id: String) {
        val list = all(ctx)
        val s = list.firstOrNull { it.id == id } ?: return
        try { Uri.parse(s.uri).path?.let { File(it).delete() } } catch (_: Exception) {}
        if (s.img.isNotEmpty()) try { File(s.img).delete() } catch (_: Exception) {}
        try { File(InjectCtl.dir(ctx), "pcm_" + s.uri.hashCode() + ".pcm").delete() } catch (_: Exception) {}
        save(ctx, list.filterNot { it.id == id })
    }

    private fun save(ctx: Context, list: List<Sound>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("uri", it.uri)
                    .put("name", it.name).put("img", it.img)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }
}
