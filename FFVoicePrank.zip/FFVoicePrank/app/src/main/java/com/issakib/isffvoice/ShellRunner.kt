package com.issakib.isffvoice

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** কমান্ড চালানোর দুই পথ: Root (su) অথবা Shizuku (রুট ছাড়া, shell পরিচয়ে)। */
object ShellRunner {
    const val REQ = 4711

    enum class Mode { NONE, ROOT, SHIZUKU }

    /** এখন যে মোডে ইনজেকশন প্রসেস চালু করা হয়েছে */
    @Volatile var mode = Mode.NONE

    fun shizukuInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
        true
    } catch (e: Exception) { false }

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun shizukuGranted(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun requestShizuku() {
        try { Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    /** Shizuku-র মাধ্যমে shell কমান্ড চালায় (newProcess এখন private, তাই reflection) */
    fun shizukuRun(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) {
        "shizuku এরর: " + (e.cause?.message ?: e.message)
    }

    /** বর্তমান মোড অনুযায়ী কমান্ড চালায় */
    fun exec(cmd: String): String = when (mode) {
        Mode.SHIZUKU -> shizukuRun(cmd)
        Mode.ROOT -> RootTools.run(cmd)
        Mode.NONE -> ""
    }

    /** কোন মোডে চালানো যাবে ঠিক করে; না পেলে null আর কারণ reason-এ */
    fun pick(ctx: Context, reason: Array<String>): Mode? {
        if (RootTools.hasRoot()) return Mode.ROOT
        if (!shizukuInstalled(ctx)) {
            reason[0] = "Root নেই। রুট ছাড়া চালাতে Shizuku অ্যাপ ইনস্টল করো ❌"
            return null
        }
        if (!shizukuRunning()) {
            reason[0] = "Shizuku চালু নেই ❌ — Shizuku অ্যাপ খুলে Start করো"
            return null
        }
        if (!shizukuGranted()) {
            requestShizuku()
            reason[0] = "Shizuku পারমিশন দাও (Allow চাপো), তারপর আবার চালু করো ❌"
            return null
        }
        return Mode.SHIZUKU
    }
}
