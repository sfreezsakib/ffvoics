package com.issakib.isffvoice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

object Player {
    private var mp: MediaPlayer? = null
    private var appCtx: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<(String?) -> Unit>()
    private var clearTask: Runnable? = null

    /** এখন যে সাউন্ডটা বাজছে তার uri (না বাজলে null) */
    @Volatile var current: String? = null
        private set

    fun addListener(l: (String?) -> Unit) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: (String?) -> Unit) { listeners.remove(l) }

    private fun setCurrent(c: String?) {
        current = c
        main.post { for (l in listeners) l(c) }
    }

    private fun cancelClear() {
        clearTask?.let { main.removeCallbacks(it) }
        clearTask = null
    }

    private fun durationOf(ctx: Context, uri: String): Long {
        return try {
            val r = MediaMetadataRetriever()
            r.setDataSource(ctx, Uri.parse(uri))
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 10000L
            r.release()
            d
        } catch (e: Exception) { 10000L }
    }

    private fun releaseMp() {
        val m = mp ?: return
        mp = null
        try { m.stop() } catch (_: Exception) {}
        try { m.release() } catch (_: Exception) {}
    }

    /** একই কার্ডে আবার চাপলে থামবে। */
    fun play(ctx: Context, uri: String): Boolean {
        val app = ctx.applicationContext
        appCtx = app
        if (current == uri) {
            stop()
            return true
        }
        cancelClear()
        if (InjectCtl.active) {
            InjectCtl.play(app, uri)
            setCurrent(uri)
            val t = Runnable { if (current == uri) setCurrent(null) }
            clearTask = t
            main.postDelayed(t, durationOf(app, uri) + 300)
            return true
        }
        releaseMp()
        val m = MediaPlayer()
        mp = m
        return try {
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            m.setDataSource(app, Uri.parse(uri))
            m.setOnCompletionListener { if (mp === m) stop() }
            m.prepare()
            m.start()
            setCurrent(uri)
            true
        } catch (e: Exception) {
            releaseMp()
            setCurrent(null)
            false
        }
    }

    fun stop() {
        cancelClear()
        appCtx?.let { if (InjectCtl.active) InjectCtl.stopPlayback(it) }
        releaseMp()
        setCurrent(null)
    }
}
