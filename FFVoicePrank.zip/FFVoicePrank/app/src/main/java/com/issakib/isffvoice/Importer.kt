package com.issakib.isffvoice

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/** অডিও/ভিডিও/ছবি অ্যাপের ভেতরে কপি করে রাখে, যাতে ফাইল সরালেও ভয়েস থাকে। */
object Importer {

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "voice"
    }

    fun baseName(ctx: Context, uri: Uri): String {
        val n = displayName(ctx, uri)
        val dot = n.lastIndexOf('.')
        val b = if (dot > 0) n.substring(0, dot) else n
        return b.ifBlank { "voice" }
    }

    private val videoExt = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi", "flv", "m4v", "ts", "mpeg", "mpg")

    /** অডিও ফাইল কপি করে; ভিডিও হলে সবসময় শুধু ভয়েস (অডিও) বের করে। */
    fun importAudio(ctx: Context, uri: Uri, id: String): File? {
        val dir = SoundStore.soundsDir(ctx)
        val mime = ctx.contentResolver.getType(uri) ?: ""
        val n = displayName(ctx, uri)
        var ext = if (n.contains('.')) n.substringAfterLast('.').lowercase() else "audio"
        val isVideo = mime.startsWith("video/") || ext in videoExt
        if (isVideo) {
            // ১) দ্রুত পদ্ধতি: অডিও ট্র্যাক সরাসরি m4a-তে
            val m4a = File(dir, "$id.m4a")
            if (extractAudio(ctx, uri, m4a)) return m4a
            m4a.delete()
            // ২) যেকোনো অডিও ফরম্যাট ডিকোড করে WAV বানানো
            val wav = File(dir, "$id.wav")
            if (convertToWav(ctx, uri, wav)) return wav
            wav.delete()
            return null // ভিডিওতে অডিও নেই বা পড়া যায়নি
        }
        if (ext.isEmpty() || ext.length > 5) ext = "audio"
        val out = File(dir, "$id.$ext")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { i ->
                out.outputStream().use { o -> i.copyTo(o) }
            } ?: return null
            if (out.length() > 0) out else { out.delete(); null }
        } catch (e: Exception) {
            out.delete()
            null
        }
    }

    private fun convertToWav(ctx: Context, uri: Uri, out: File): Boolean {
        val tmp = File(out.parentFile, out.name + ".pcm")
        try {
            if (!PcmConverter.convert(ctx, uri, tmp)) return false
            val len = tmp.length().toInt()
            val rate = 48000
            val h = ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(36 + len); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
            h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(len)
            out.outputStream().use { o ->
                o.write(h.array())
                tmp.inputStream().use { it.copyTo(o) }
            }
            return out.length() > 44
        } catch (e: Exception) {
            return false
        } finally {
            tmp.delete()
        }
    }

    private fun extractAudio(ctx: Context, uri: Uri, out: File): Boolean {
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("audio/")) { idx = i; break }
            }
            if (idx < 0) return false
            ex.selectTrack(idx)
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val track = muxer.addTrack(ex.getTrackFormat(idx))
            muxer.start()
            val buf = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                    MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, n, ex.sampleTime, flags)
                muxer.writeSampleData(track, buf, info)
                ex.advance()
            }
            muxer.stop()
            return out.length() > 0
        } catch (e: Exception) {
            return false
        } finally {
            try { muxer?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }

    /** ছবি স্কয়ার করে ছোট করে সেভ করে; পাথ ফেরত দেয়। */
    fun importImage(ctx: Context, uri: Uri, id: String): String? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 900) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            var deg = 0
            try {
                ctx.contentResolver.openInputStream(uri)?.use {
                    deg = when (ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270
                        else -> 0
                    }
                }
            } catch (_: Exception) {}
            if (deg != 0) {
                val m = Matrix().apply { postRotate(deg.toFloat()) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val side = min(bmp.width, bmp.height)
            var sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            if (side > 400) sq = Bitmap.createScaledBitmap(sq, 400, 400, true)

            val f = File(SoundStore.imagesDir(ctx), id + "_" + System.currentTimeMillis() + ".jpg")
            f.outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            return f.absolutePath
        } catch (e: Exception) {
            return null
        }
    }
}
