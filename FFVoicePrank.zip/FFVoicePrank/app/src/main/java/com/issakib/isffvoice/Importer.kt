package com.issakib.isffvoice

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/** অডিও/ভিডিও/ছবি অ্যাপের ভেতরে কপি করে রাখে, যাতে ফাইল সরালেও ভয়েস থাকে। */
object Importer {

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "voice"
    }

    fun baseName(ctx: Context, uri: Uri): String {
        val n = displayName(ctx, uri)
        val dot = n.lastIndexOf('.')
        val b = if (dot > 0) n.substring(0, dot) else n
        return b.ifBlank { "voice" }
    }

    /** অডিও ফাইল কপি করে; ভিডিও হলে শুধু অডিও অংশ বের করে। */
    fun importAudio(ctx: Context, uri: Uri, id: String): File? {
        val dir = SoundStore.soundsDir(ctx)
        val mime = ctx.contentResolver.getType(uri) ?: ""
        if (mime.startsWith("video/")) {
            val f = File(dir, "$id.m4a")
            if (extractAudio(ctx, uri, f)) return f
            f.delete()
        }
        val n = displayName(ctx, uri)
        var ext = if (n.contains('.')) n.substringAfterLast('.').lowercase() else "audio"
        if (ext.isEmpty() || ext.length > 5) ext = "audio"
        val out = File(dir, "$id.$ext")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { i ->
                out.outputStream().use { o -> i.copyTo(o) }
            } ?: return null
            if (out.length() > 0) out else { out.delete(); null }
        } catch (e: Exception) {
            out.delete()
            null
        }
    }

    private fun extractAudio(ctx: Context, uri: Uri, out: File): Boolean {
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("audio/")) { idx = i; break }
            }
            if (idx < 0) return false
            ex.selectTrack(idx)
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val track = muxer.addTrack(ex.getTrackFormat(idx))
            muxer.start()
            val buf = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                    MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, n, ex.sampleTime, flags)
                muxer.writeSampleData(track, buf, info)
                ex.advance()
            }
            muxer.stop()
            return out.length() > 0
        } catch (e: Exception) {
            return false
        } finally {
            try { muxer?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }

    /** ছবি স্কয়ার করে ছোট করে সেভ করে; পাথ ফেরত দেয়। */
    fun importImage(ctx: Context, uri: Uri, id: String): String? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 900) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            var deg = 0
            try {
                ctx.contentResolver.openInputStream(uri)?.use {
                    deg = when (ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270
                        else -> 0
                    }
                }
            } catch (_: Exception) {}
            if (deg != 0) {
                val m = Matrix().apply { postRotate(deg.toFloat()) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val side = min(bmp.width, bmp.height)
            var sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            if (side > 400) sq = Bitmap.createScaledBitmap(sq, 400, 400, true)

            val f = File(SoundStore.imagesDir(ctx), id + "_" + System.currentTimeMillis() + ".jpg")
            f.outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            return f.absolutePath
        } catch (e: Exception) {
            return null
        }
    }
}
