package com.issakib.isffvoice

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** যেকোনো অডিও ফাইলকে 48kHz, mono, 16-bit PCM ফাইলে বদলায়। */
object PcmConverter {
    private const val OUT_RATE = 48000

    /** 16-bit PCM WAV হলে MediaCodec ছাড়াই সরাসরি পড়ে (হেডার ভাঙা থাকলেও চলে) */
    private fun readWav(path: String): Triple<ByteArray, Int, Int>? {
        return try {
            val b = File(path).readBytes()
            if (b.size < 44 || String(b, 0, 4, Charsets.ISO_8859_1) != "RIFF") return null
            var i = 12
            var rate = 0
            var ch = 0
            var bits = 0
            while (i + 8 <= b.size) {
                val id = String(b, i, 4, Charsets.ISO_8859_1)
                val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                val sz = bb.getInt(i + 4)
                if (id == "fmt ") {
                    ch = bb.getShort(i + 10).toInt()
                    rate = bb.getInt(i + 12)
                    bits = bb.getShort(i + 22).toInt()
                } else if (id == "data") {
                    if (bits != 16 || rate <= 0 || ch <= 0) return null
                    val end = if (sz <= 0 || i + 8 + sz > b.size) b.size else i + 8 + sz
                    return Triple(b.copyOfRange(i + 8, end), rate, ch)
                }
                if (sz < 0) return null
                i += 8 + sz + (sz and 1)
            }
            null
        } catch (e: Exception) { null }
    }

    fun convert(ctx: Context, uri: Uri, out: File): Boolean {
        if (uri.scheme == "file" && (uri.path ?: "").endsWith(".wav", true)) {
            val w = readWav(uri.path!!)
            if (w != null && finish(w.first, w.second, w.third, out)) return true
        }
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    idx = i; fmt = f; break
                }
            }
            if (idx < 0 || fmt == null) return false
            ex.selectTrack(idx)

            val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()

            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val info = MediaCodec.BufferInfo()
            val pcm = ByteArrayOutputStream()
            var inDone = false
            var outDone = false

            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10000)
                    if (i >= 0) {
                        val b = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(b, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10000)
                if (o >= 0) {
                    val b = codec.getOutputBuffer(o)!!
                    val arr = ByteArray(info.size)
                    b.position(info.offset)
                    b.get(arr)
                    pcm.write(arr)
                    codec.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            codec.stop()
            codec.release()

            if (!finish(pcm.toByteArray(), rate, ch, out)) return false
            return true
        } catch (e: Exception) {
            return false
        } finally {
            try { ex.release() } catch (_: Exception) {}
        }
    }

    /** 16-bit PCM → mono, 48kHz ফাইল */
    private fun finish(data: ByteArray, rate: Int, ch: Int, out: File): Boolean {
        val sb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val total = sb.remaining() / ch
        if (total <= 0) return false
        val mono = ShortArray(total)
        for (k in 0 until total) {
            var s = 0
            for (c in 0 until ch) s += sb.get(k * ch + c)
            mono[k] = (s / ch).toShort()
        }
        val outLen = (total.toLong() * OUT_RATE / rate).toInt()
        val res = ByteBuffer.allocate(outLen * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (k in 0 until outLen) {
            val pos = k.toDouble() * rate / OUT_RATE
            val i0 = pos.toInt().coerceAtMost(total - 1)
            val i1 = (i0 + 1).coerceAtMost(total - 1)
            val fr = pos - i0
            res.putShort((mono[i0] * (1 - fr) + mono[i1] * fr).toInt().toShort())
        }
        out.writeBytes(res.array())
        return true
    }
}
