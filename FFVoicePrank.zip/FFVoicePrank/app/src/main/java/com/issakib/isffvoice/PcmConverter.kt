package com.issakib.isffvoice

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** যেকোনো অডিও ফাইলকে 48kHz, mono, 16-bit PCM ফাইলে বদলায়। */
object PcmConverter {
    private const val OUT_RATE = 48000

    fun convert(ctx: Context, uri: Uri, out: File): Boolean {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    idx = i; fmt = f; break
                }
            }
            if (idx < 0 || fmt == null) return false
            ex.selectTrack(idx)

            val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()

            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val info = MediaCodec.BufferInfo()
            val pcm = ByteArrayOutputStream()
            var inDone = false
            var outDone = false

            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10000)
                    if (i >= 0) {
                        val b = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(b, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10000)
                if (o >= 0) {
                    val b = codec.getOutputBuffer(o)!!
                    val arr = ByteArray(info.size)
                    b.position(info.offset)
                    b.get(arr)
                    pcm.write(arr)
                    codec.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            codec.stop()
            codec.release()

            val sb = ByteBuffer.wrap(pcm.toByteArray()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val total = sb.remaining() / ch
            if (total <= 0) return false
            val mono = ShortArray(total)
            for (k in 0 until total) {
                var s = 0
                for (c in 0 until ch) s += sb.get(k * ch + c)
                mono[k] = (s / ch).toShort()
            }

            val outLen = (total.toLong() * OUT_RATE / rate).toInt()
            val res = ByteBuffer.allocate(outLen * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (k in 0 until outLen) {
                val pos = k.toDouble() * rate / OUT_RATE
                val i0 = pos.toInt().coerceAtMost(total - 1)
                val i1 = (i0 + 1).coerceAtMost(total - 1)
                val fr = pos - i0
                res.putShort((mono[i0] * (1 - fr) + mono[i1] * fr).toInt().toShort())
            }
            out.writeBytes(res.array())
            return true
        } catch (e: Exception) {
            return false
        } finally {
            try { ex.release() } catch (_: Exception) {}
        }
    }
}
