package com.issakib.isffvoice

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.ServiceCompat
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        var onState: ((Boolean) -> Unit)? = null
        const val ACT_TOGGLE = "com.issakib.isffvoice.TOGGLE"
        const val ACT_STOP = "com.issakib.isffvoice.STOP"
        const val ACT_CLOSE = "com.issakib.isffvoice.CLOSE"
    }

    private var wm: WindowManager? = null
    private var bubble: FrameLayout? = null
    private var panel: View? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private val cards = HashMap<String, SoundCard>()
    private var hidden = false
    private var injectChip: TextView? = null
    private var injectBusy = false
    private val handler = Handler(Looper.getMainLooper())

    private val playListener: (String?) -> Unit = { cur ->
        for ((u, c) in cards) c.setPlaying(u == cur)
    }
    private val fadeRun = Runnable {
        if (!hidden && panel == null) bubble?.animate()?.alpha(0.55f)?.setDuration(400)?.start()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun sw() = resources.displayMetrics.widthPixels
    private fun sh() = resources.displayMetrics.heightPixels
    private val bubbleSize get() = dp(54)

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
        Player.addListener(playListener)
        running = true
        onState?.invoke(true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_TOGGLE -> setHidden(!hidden)
            ACT_STOP -> Player.stop()
            ACT_CLOSE -> stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 9, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("IS FF VOICE")
            .setContentText("ওভারলে চালু আছে")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_view, "দেখাও/লুকাও", pi(ACT_TOGGLE, 1))
            .addAction(android.R.drawable.ic_media_pause, "থামাও", pi(ACT_STOP, 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ", pi(ACT_CLOSE, 3))
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    private fun newParams(w: Int, h: Int, extra: Int = 0) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or extra,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    // ---------- বাবল ----------
    private fun addBubble() {
        val size = bubbleSize
        val img = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            Ui.clipRound(this, -1f)
        }
        val b = FrameLayout(this).apply {
            background = Ui.oval(Ui.BG0, Ui.CYAN, dp(2))
            setPadding(dp(3), dp(3), dp(3), dp(3))
            addView(img, FrameLayout.LayoutParams(-1, -1))
            alpha = 0.95f
        }
        bubbleLp = newParams(size, size, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS).apply {
            x = dp(4)
            y = dp(200)
        }

        b.setOnTouchListener(object : View.OnTouchListener {
            var ix = 0
            var iy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            var longFired = false
            val longRun = Runnable {
                if (!moved) {
                    longFired = true
                    setHidden(!hidden)
                }
            }

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ix = bubbleLp.x; iy = bubbleLp.y
                        tx = e.rawX; ty = e.rawY
                        moved = false
                        longFired = false
                        handler.removeCallbacks(fadeRun)
                        b.animate().cancel()
                        b.alpha = if (hidden) 0.7f else 0.95f
                        handler.postDelayed(longRun, 600)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                            moved = true
                            handler.removeCallbacks(longRun)
                        }
                        if (moved) {
                            bubbleLp.x = ix + dx
                            bubbleLp.y = (iy + dy).coerceIn(0, maxOf(0, sh() - bubbleLp.height))
                            try { wm?.updateViewLayout(v, bubbleLp) } catch (_: Exception) {}
                            if (panel != null) layoutPanel()
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(longRun)
                        if (moved) {
                            snapToEdge()
                        } else if (!longFired && e.action == MotionEvent.ACTION_UP) {
                            if (hidden) setHidden(false) else togglePanel()
                        }
                        if (hidden) b.alpha = 0.5f
                        scheduleFade()
                    }
                }
                return true
            }
        })

        bubble = b
        wm?.addView(b, bubbleLp)
        scheduleFade()
    }

    private fun scheduleFade() {
        handler.removeCallbacks(fadeRun)
        if (!hidden && panel == null) handler.postDelayed(fadeRun, 3000)
    }

    private fun snapToEdge() {
        val b = bubble ?: return
        val w = bubbleLp.width
        val toLeft = bubbleLp.x + w / 2 < sw() / 2
        val target = if (hidden) {
            if (toLeft) -w / 2 else sw() - w / 2
        } else {
            if (toLeft) dp(4) else sw() - w - dp(4)
        }
        ValueAnimator.ofInt(bubbleLp.x, target).apply {
            duration = 180
            addUpdateListener {
                bubbleLp.x = it.animatedValue as Int
                try { wm?.updateViewLayout(b, bubbleLp) } catch (_: Exception) {}
                if (panel != null) layoutPanel()
            }
            start()
        }
    }

    /** বাবলটা ছোট করে স্ক্রিনের কিনারায় লুকায় / আবার বের করে */
    private fun setHidden(h: Boolean) {
        val b = bubble ?: return
        hidden = h
        closePanel()
        val s = if (h) dp(30) else bubbleSize
        val left = bubbleLp.x + bubbleLp.width / 2 < sw() / 2
        bubbleLp.width = s
        bubbleLp.height = s
        bubbleLp.x = if (h) {
            if (left) -s / 2 else sw() - s / 2
        } else {
            if (left) dp(4) else sw() - s - dp(4)
        }
        bubbleLp.y = bubbleLp.y.coerceIn(0, maxOf(0, sh() - s))
        b.animate().cancel()
        b.alpha = if (h) 0.5f else 0.95f
        try { wm?.updateViewLayout(b, bubbleLp) } catch (_: Exception) {}
        scheduleFade()
    }

    // ---------- প্যানেল ----------
    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        panel = null
        injectChip = null
        cards.clear()
        scheduleFade()
    }

    private fun iconBtn(label: String, bg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = Ui.oval(bg, Ui.CYAN, dp(1))
            isClickable = true
            setOnClickListener { onClick() }
            Ui.pressable(this)
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply { leftMargin = dp(6) }
        }

    private fun openPanel() {
        val sounds = SoundStore.all(this)
        val pw = minOf(dp(268), sw() - dp(16))
        val cols = 3
        val padIn = dp(8)
        val gap = dp(6)
        val side = (pw - padIn * 2 - gap * (cols - 1)) / cols

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rect(0xF2070E3A.toInt(), dp(18), Ui.CYAN, dp(1))
            setPadding(padIn, padIn, padIn, padIn)
        }

        // হেডার: নাম + থামাও / লুকাও / বন্ধ
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(
            TextView(this).apply {
                text = "⠿ 👑 IS FF VOICE"
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Ui.CYAN)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(iconBtn("⏹", 0xFF8A1030.toInt()) { Player.stop() })
        head.addView(iconBtn("➖", 0xFF14246B.toInt()) { setHidden(true) })
        head.addView(iconBtn("✖", 0xFF14246B.toInt()) { stopSelf() })
        // হেডার ধরে টেনে পুরো প্যানেল (বাবল সহ) সরানো যাবে
        head.setOnTouchListener(object : View.OnTouchListener {
            var lx = 0f
            var ly = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - lx).toInt()
                        val dy = (e.rawY - ly).toInt()
                        lx = e.rawX; ly = e.rawY
                        movePanelBy(dx, dy)
                    }
                }
                return true
            }
        })
        box.addView(head)

        // ভলিউম
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val volRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }
        volRow.addView(TextView(this).apply { text = "🔊"; textSize = 12f })
        volRow.addView(
            SeekBar(this).apply {
                max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                progressTintList = ColorStateList.valueOf(Ui.CYAN)
                thumbTintList = ColorStateList.valueOf(Ui.CYAN)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                        if (fromUser) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        box.addView(volRow)

        // Root ইনজেকশন অন/অফ
        val chip = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(6), dp(8), dp(6))
            isClickable = true
            setOnClickListener { toggleInject() }
            Ui.pressable(this)
        }
        injectChip = chip
        refreshInjectChip()
        box.addView(chip, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(2)
            bottomMargin = dp(2)
        })

        // ভয়েস গ্রিড (৩ কলাম, ছোট কার্ড)
        val gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (sounds.isEmpty()) {
            gridBox.addView(TextView(this).apply {
                text = "কোনো ভয়েস নেই\nঅ্যাপ থেকে যোগ করো"
                setTextColor(Ui.MUTED)
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
            })
        }
        var i = 0
        while (i < sounds.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                val idx = i + c
                if (idx >= sounds.size) break
                val s = sounds[idx]
                val card = SoundCard(this, s, side, true)
                card.setOnClickListener { Player.play(this, s.uri) }
                card.setPlaying(Player.current == s.uri)
                cards[s.uri] = card
                row.addView(card, LinearLayout.LayoutParams(side, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (c < cols - 1) rightMargin = gap
                })
            }
            gridBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = gap })
            i += cols
        }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(gridBox)
        }
        box.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        // প্যানেলের উচ্চতা: কনটেন্ট অনুযায়ী, কিন্তু স্ক্রিনের ৫৫% এর বেশি নয়
        val rows = if (sounds.isEmpty()) 0 else (sounds.size + cols - 1) / cols
        val gridH = if (sounds.isEmpty()) dp(60) else rows * (side + dp(22) + gap) + gap
        val fixed = dp(36) + dp(34) + dp(36) + padIn * 2
        val maxH = minOf(dp(330), (sh() * 0.55f).toInt())
        val ph = minOf(fixed + gridH, maxH)

        panelLp = newParams(pw, ph)
        panel = box
        computePanelPos()
        box.alpha = 0f
        box.scaleY = 0.9f
        box.pivotY = 0f
        wm?.addView(box, panelLp)
        box.animate().alpha(1f).scaleY(1f).setDuration(160).start()
        handler.removeCallbacks(fadeRun)
    }

    private fun movePanelBy(dx: Int, dy: Int) {
        val p = panel ?: return
        val b = bubble ?: return
        val nx = (panelLp.x + dx).coerceIn(0, maxOf(0, sw() - panelLp.width))
        val ny = (panelLp.y + dy).coerceIn(0, maxOf(0, sh() - panelLp.height))
        val ddx = nx - panelLp.x
        val ddy = ny - panelLp.y
        panelLp.x = nx
        panelLp.y = ny
        bubbleLp.x += ddx
        bubbleLp.y = (bubbleLp.y + ddy).coerceIn(0, maxOf(0, sh() - bubbleLp.height))
        try { wm?.updateViewLayout(p, panelLp) } catch (_: Exception) {}
        try { wm?.updateViewLayout(b, bubbleLp) } catch (_: Exception) {}
    }

    private fun refreshInjectChip() {
        val c = injectChip ?: return
        val on = InjectCtl.active
        c.text = if (on) "🎙 Root Inject: ON ✅  (ট্যাপ করে বন্ধ)" else "🎙 Root Inject: OFF  (ট্যাপ করে চালু)"
        c.background = if (on) Ui.rect(0xFF0E7A55.toInt(), dp(10), Ui.GREEN, dp(1))
        else Ui.rect(0xFF14246B.toInt(), dp(10), 0x663A55C0, dp(1))
    }

    private fun toggleInject() {
        if (injectBusy) return
        injectBusy = true
        val turnOn = !InjectCtl.active
        if (!turnOn) Player.stop()
        injectChip?.text = if (turnOn) "⏳ চালু হচ্ছে..." else "⏳ বন্ধ হচ্ছে..."
        Thread {
            val msg = if (turnOn) {
                if (RootTools.hasRoot()) InjectCtl.start(this) else "Root নেই ❌"
            } else {
                InjectCtl.stop(this)
                "ইনজেকশন বন্ধ"
            }
            handler.post {
                injectBusy = false
                refreshInjectChip()
                Toast.makeText(this, msg.lines().first(), Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun computePanelPos() {
        val bs = bubbleLp.width
        val pw = panelLp.width
        val ph = panelLp.height
        val x = bubbleLp.x + bs / 2 - pw / 2
        panelLp.x = x.coerceIn(dp(4), maxOf(dp(4), sw() - pw - dp(4)))
        var y = bubbleLp.y + bs + dp(6)
        if (y + ph > sh() - dp(24)) y = maxOf(dp(24), bubbleLp.y - ph - dp(6))
        panelLp.y = y
    }

    private fun layoutPanel() {
        val p = panel ?: return
        computePanelPos()
        try { wm?.updateViewLayout(p, panelLp) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Player.removeListener(playListener)
        try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        panel = null
        bubble = null
        cards.clear()
        val wasRunning = running
        running = false
        Player.stop()
        if (wasRunning) onState?.invoke(false)
        super.onDestroy()
    }
}
