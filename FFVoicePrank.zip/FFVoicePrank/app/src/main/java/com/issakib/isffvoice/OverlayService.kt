package com.issakib.isffvoice

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.ServiceCompat
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        var onState: ((Boolean) -> Unit)? = null
        const val ACT_TOGGLE = "com.issakib.isffvoice.TOGGLE"
        const val ACT_STOP = "com.issakib.isffvoice.STOP"
        const val ACT_CLOSE = "com.issakib.isffvoice.CLOSE"
    }

    private var wm: WindowManager? = null
    private var bubble: FrameLayout? = null
    private var panel: View? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private val cards = HashMap<String, SoundCard>()
    private var hidden = false
    private var injectChip: TextView? = null
    private var injectBusy = false
    private var ttsEt: EditText? = null
    private var ttsStatus: TextView? = null
    private var body: LinearLayout? = null
    private var tab = 0
    private var draft = ""
    private val tabViews = arrayOfNulls<TextView>(2)
    private var panelCols = 3
    private var panelGap = 0
    private var panelSide = 0
    private var panelMaxH = 0
    private var typing = false
    private val handler = Handler(Looper.getMainLooper())

    private val playListener: (String?) -> Unit = { cur ->
        for ((u, c) in cards) c.setPlaying(u == cur)
    }
    private val fadeRun = Runnable {
        if (!hidden && panel == null) bubble?.animate()?.alpha(0.55f)?.setDuration(400)?.start()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // স্ক্রিন ঘুরলে প্যানেল বন্ধ করে বাবলকে স্ক্রিনের ভেতরে আনো
        closePanel()
        val b = bubble ?: return
        val left = bubbleLp.x + bubbleLp.width / 2 < sw() / 2
        bubbleLp.x = if (hidden) { if (left) -bubbleLp.width / 2 else sw() - bubbleLp.width / 2 }
        else { if (left) dp(4) else sw() - bubbleLp.width - dp(4) }
        bubbleLp.y = bubbleLp.y.coerceIn(0, maxOf(0, sh() - bubbleLp.height))
        try { wm?.updateViewLayout(b, bubbleLp) } catch (_: Exception) {}
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun sw() = resources.displayMetrics.widthPixels
    private fun sh() = resources.displayMetrics.heightPixels
    private val bubbleSize get() = dp(54)

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
        Player.addListener(playListener)
        running = true
        onState?.invoke(true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_TOGGLE -> setHidden(!hidden)
            ACT_STOP -> Player.stop()
            ACT_CLOSE -> stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 9, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "overlay")
            .setContentTitle("IS FF VOICE")
            .setContentText("ওভারলে চালু আছে")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_view, "দেখাও/লুকাও", pi(ACT_TOGGLE, 1))
            .addAction(android.R.drawable.ic_media_pause, "থামাও", pi(ACT_STOP, 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ", pi(ACT_CLOSE, 3))
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    private fun newParams(w: Int, h: Int, extra: Int = 0) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or extra,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    // ---------- বাবল ----------
    private fun addBubble() {
        val size = bubbleSize
        val img = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            Ui.clipRound(this, -1f)
        }
        val b = FrameLayout(this).apply {
            background = Ui.oval(Ui.BG0, Ui.CYAN, dp(2))
            setPadding(dp(3), dp(3), dp(3), dp(3))
            addView(img, FrameLayout.LayoutParams(-1, -1))
            alpha = 0.95f
        }
        bubbleLp = newParams(size, size, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS).apply {
            x = dp(4)
            y = dp(200)
        }

        b.setOnTouchListener(object : View.OnTouchListener {
            var ix = 0
            var iy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            var longFired = false
            val longRun = Runnable {
                if (!moved) {
                    longFired = true
                    setHidden(!hidden)
                }
            }

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ix = bubbleLp.x; iy = bubbleLp.y
                        tx = e.rawX; ty = e.rawY
                        moved = false
                        longFired = false
                        handler.removeCallbacks(fadeRun)
                        b.animate().cancel()
                        b.alpha = if (hidden) 0.7f else 0.95f
                        handler.postDelayed(longRun, 600)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                            moved = true
                            handler.removeCallbacks(longRun)
                        }
                        if (moved) {
                            bubbleLp.x = ix + dx
                            bubbleLp.y = (iy + dy).coerceIn(0, maxOf(0, sh() - bubbleLp.height))
                            try { wm?.updateViewLayout(v, bubbleLp) } catch (_: Exception) {}
                            if (panel != null) layoutPanel()
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(longRun)
                        if (moved) {
                            snapToEdge()
                        } else if (!longFired && e.action == MotionEvent.ACTION_UP) {
                            if (hidden) setHidden(false) else togglePanel()
                        }
                        if (hidden) b.alpha = 0.5f
                        scheduleFade()
                    }
                }
                return true
            }
        })

        bubble = b
        wm?.addView(b, bubbleLp)
        scheduleFade()
    }

    private fun scheduleFade() {
        handler.removeCallbacks(fadeRun)
        if (!hidden && panel == null) handler.postDelayed(fadeRun, 3000)
    }

    private fun snapToEdge() {
        val b = bubble ?: return
        val w = bubbleLp.width
        val toLeft = bubbleLp.x + w / 2 < sw() / 2
        val target = if (hidden) {
            if (toLeft) -w / 2 else sw() - w / 2
        } else {
            if (toLeft) dp(4) else sw() - w - dp(4)
        }
        ValueAnimator.ofInt(bubbleLp.x, target).apply {
            duration = 180
            addUpdateListener {
                bubbleLp.x = it.animatedValue as Int
                try { wm?.updateViewLayout(b, bubbleLp) } catch (_: Exception) {}
                if (panel != null) layoutPanel()
            }
            start()
        }
    }

    /** বাবলটা ছোট করে স্ক্রিনের কিনারায় লুকায় / আবার বের করে */
    private fun setHidden(h: Boolean) {
        val b = bubble ?: return
        hidden = h
        closePanel()
        val s = if (h) dp(30) else bubbleSize
        val left = bubbleLp.x + bubbleLp.width / 2 < sw() / 2
        bubbleLp.width = s
        bubbleLp.height = s
        bubbleLp.x = if (h) {
            if (left) -s / 2 else sw() - s / 2
        } else {
            if (left) dp(4) else sw() - s - dp(4)
        }
        bubbleLp.y = bubbleLp.y.coerceIn(0, maxOf(0, sh() - s))
        b.animate().cancel()
        b.alpha = if (h) 0.5f else 0.95f
        try { wm?.updateViewLayout(b, bubbleLp) } catch (_: Exception) {}
        scheduleFade()
    }

    // ---------- প্যানেল ----------
    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        panel = null
        injectChip = null
        ttsEt = null
        ttsStatus = null
        body = null
        typing = false
        cards.clear()
        scheduleFade()
    }

    private fun iconBtn(label: String, bg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = Ui.oval(bg, Ui.CYAN, dp(1))
            isClickable = true
            setOnClickListener { onClick() }
            Ui.pressable(this)
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { leftMargin = dp(6) }
        }

    private fun isLandscape() = sw() > sh()

    private fun styleTab(t: TextView, on: Boolean) {
        t.background = if (on) Ui.grad(Ui.CYAN, Ui.PURPLE, dp(12))
        else Ui.rect(0xFF14246B.toInt(), dp(12), 0x663A55C0, dp(1))
        t.setTextColor(Color.WHITE)
    }

    private fun openPanel() {
        val land = isLandscape()
        val pw = minOf(if (land) dp(430) else dp(310), sw() - dp(16))
        val padIn = dp(10)
        panelCols = if (pw >= dp(380)) 4 else 3
        panelGap = dp(6)
        panelSide = (pw - padIn * 2 - panelGap * (panelCols - 1)) / panelCols
        panelMaxH = if (land) sh() - dp(12) else minOf(dp(460), (sh() * 0.72f).toInt())

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rect(0xF2070E3A.toInt(), dp(18), Ui.CYAN, dp(1))
            setPadding(padIn, padIn, padIn, padIn)
        }

        // হেডার: নাম + থামাও / লুকাও / বন্ধ (ধরে টেনে সরানো যাবে)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(
            TextView(this).apply {
                text = "⠿ 👑 IS FF VOICE"
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Ui.CYAN)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(iconBtn("⏹", 0xFF8A1030.toInt()) { Player.stop() })
        head.addView(iconBtn("➖", 0xFF14246B.toInt()) { setHidden(true) })
        head.addView(iconBtn("✖", 0xFF14246B.toInt()) { stopSelf() })
        head.setOnTouchListener(object : View.OnTouchListener {
            var lx = 0f
            var ly = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - lx).toInt()
                        val dy = (e.rawY - ly).toInt()
                        lx = e.rawX; ly = e.rawY
                        movePanelBy(dx, dy)
                    }
                }
                return true
            }
        })
        box.addView(head)

        // এক সারিতে: Root Inject বোতাম + ভলিউম
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val ctlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(4))
        }
        val chip = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            isClickable = true
            setOnClickListener { toggleInject() }
            Ui.pressable(this)
        }
        injectChip = chip
        refreshInjectChip()
        ctlRow.addView(chip, LinearLayout.LayoutParams(-2, -2))
        ctlRow.addView(TextView(this).apply { text = "🔊"; textSize = 13f; setPadding(dp(8), 0, 0, 0) })
        ctlRow.addView(
            SeekBar(this).apply {
                max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                progressTintList = ColorStateList.valueOf(Ui.CYAN)
                thumbTintList = ColorStateList.valueOf(Ui.CYAN)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                        if (fromUser) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        box.addView(ctlRow)

        // ট্যাব: 🎵 সাউন্ড কার্ড | 🗣 টেক্সট → ভয়েস  (দুটো আর একসাথে গাদাগাদি করে না)
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val labels = arrayOf("🎵 সাউন্ড কার্ড", "🗣 লিখে সেন্ড")
        for (i in 0..1) {
            val t = TextView(this).apply {
                text = labels[i]
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(0, dp(9), 0, dp(9))
                isClickable = true
                setOnClickListener {
                    if (tab != i) { endTyping(); tab = i; showTab() }
                }
                Ui.pressable(this)
            }
            tabViews[i] = t
            tabRow.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (i == 0) rightMargin = dp(6)
            })
        }
        box.addView(tabRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })

        val b = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body = b
        box.addView(b, LinearLayout.LayoutParams(-1, 0, 1f))

        box.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_OUTSIDE) endTyping()
            false
        }

        panelLp = newParams(pw, dp(300))
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        panel = box
        showTab()
        box.alpha = 0f
        box.scaleY = 0.9f
        box.pivotY = 0f
        wm?.addView(box, panelLp)
        box.animate().alpha(1f).scaleY(1f).setDuration(160).start()
        handler.removeCallbacks(fadeRun)
    }

    /** ট্যাব বদলালে ভেতরের পেজ আর প্যানেলের উচ্চতা বদলায় */
    private fun showTab() {
        val b = body ?: return
        b.removeAllViews()
        cards.clear()
        ttsEt = null
        ttsStatus = null
        for (i in 0..1) tabViews[i]?.let { styleTab(it, i == tab) }

        val chrome = dp(150)
        val ph: Int
        if (tab == 0) {
            val sounds = SoundStore.all(this)
            val rows = if (sounds.isEmpty()) 0 else (sounds.size + panelCols - 1) / panelCols
            val gridH = if (sounds.isEmpty()) dp(70) else rows * (panelSide + dp(24) + panelGap) + panelGap
            ph = minOf(chrome + gridH, panelMaxH)
            b.addView(buildCardsPage(sounds), LinearLayout.LayoutParams(-1, -1))
        } else {
            ph = minOf(chrome + dp(165), panelMaxH)
            b.addView(buildTtsPage(), LinearLayout.LayoutParams(-1, -1))
        }
        val p = panel ?: return
        panelLp.height = ph
        computePanelPos()
        try { wm?.updateViewLayout(p, panelLp) } catch (_: Exception) {}
    }

    private fun buildCardsPage(sounds: List<Sound>): View {
        val gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (sounds.isEmpty()) {
            gridBox.addView(TextView(this).apply {
                text = "কোনো ভয়েস নেই\nঅ্যাপ থেকে যোগ করো"
                setTextColor(Ui.MUTED)
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(0, dp(18), 0, dp(18))
            })
        }
        var i = 0
        while (i < sounds.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until panelCols) {
                val idx = i + c
                if (idx >= sounds.size) break
                val s = sounds[idx]
                val card = SoundCard(this, s, panelSide, true)
                card.setOnClickListener { Player.play(this, s.uri) }
                card.setPlaying(Player.current == s.uri)
                cards[s.uri] = card
                row.addView(card, LinearLayout.LayoutParams(panelSide, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (c < panelCols - 1) rightMargin = panelGap
                })
            }
            gridBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = panelGap })
            i += panelCols
        }
        return ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(gridBox)
        }
    }

    private fun buildTtsPage(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // কোন ক্লোন ভয়েসে বাজবে
        val voiceScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val voiceRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, dp(4))
        }
        voiceScroll.addView(voiceRow)
        fun fillVoices() {
            voiceRow.removeAllViews()
            val vs = Tts.voices(this)
            val sel = Tts.selected(this)?.id
            if (vs.isEmpty()) {
                voiceRow.addView(TextView(this).apply {
                    text = "🎭 ক্লোন ভয়েস নেই — অ্যাপ থেকে যোগ করো"
                    textSize = 11f
                    setTextColor(Ui.MUTED)
                })
            }
            for (v in vs) {
                voiceRow.addView(TextView(this).apply {
                    text = "🎭 " + v.name
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    setPadding(dp(12), dp(7), dp(12), dp(7))
                    background = if (v.id == sel) Ui.rect(0xFF0E7A55.toInt(), dp(14), Ui.GREEN, dp(1))
                    else Ui.rect(0xFF14246B.toInt(), dp(14), 0x663A55C0, dp(1))
                    isClickable = true
                    setOnClickListener {
                        Tts.select(this@OverlayService, v.id)
                        fillVoices()
                    }
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }
                })
            }
        }
        fillVoices()
        col.addView(voiceScroll)

        // লেখার ঘর + সেন্ড বোতাম (পাশাপাশি)
        val et = EditText(this).apply {
            hint = "🗣 এখানে লেখো..."
            setHintTextColor(Ui.MUTED)
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 2
            maxLines = 3
            gravity = Gravity.TOP
            setText(draft)
            imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            background = Ui.rect(0xFF0A1448.toInt(), dp(12), 0x663A55C0, dp(1))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { draft = s?.toString() ?: "" }
            })
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEND) { sendTts(this); true } else false
            }
            setOnTouchListener { v, ev ->
                if (ev.action == MotionEvent.ACTION_DOWN) setPanelFocusable(true)
                if (ev.action == MotionEvent.ACTION_UP) {
                    v.postDelayed({
                        v.requestFocus()
                        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
                    }, 120)
                }
                false
            }
        }
        ttsEt = et
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(
            Ui.button(this, "➤\nসেন্ড", Ui.GREEN, Ui.CYAN, 12f) { sendTts(et) },
            LinearLayout.LayoutParams(dp(64), -2).apply { leftMargin = dp(6) }
        )
        col.addView(row)

        // আবার বাজাও / মুছো
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(
            Ui.button(this, "🔁 আবার বাজাও", Ui.PURPLE, 0xFF5B3BFF.toInt(), 12f) {
                val f = Tts.lastFile
                if (f != null && f.exists()) Player.play(this, Uri.fromFile(f).toString())
                else ttsStatus?.text = "আগে একটা ভয়েস বানাও"
            }.apply { setPadding(dp(8), dp(9), dp(8), dp(9)) },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        row2.addView(
            Ui.button(this, "🗑 মুছো", 0xFF14246B.toInt(), 0xFF1B2F8A.toInt(), 12f) {
                et.setText("")
            }.apply { setPadding(dp(8), dp(9), dp(8), dp(9)) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) }
        )
        col.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val st = TextView(this).apply {
            textSize = 11f
            setTextColor(Ui.MUTED)
            setPadding(dp(2), dp(6), dp(2), dp(2))
        }
        ttsStatus = st
        col.addView(st)

        return ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
        }
    }

    /** লেখার সময় প্যানেল ফোকাসেবল হয় (কীবোর্ড আসে) এবং উপরে উঠে যায় */
    private fun setPanelFocusable(f: Boolean) {
        val p = panel ?: return
        if (f) {
            if (typing) return
            typing = true
            panelLp.flags = (panelLp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()) or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            panelLp.y = dp(8)
        } else {
            if (!typing) return
            typing = false
            panelLp.flags = (panelLp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) and
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH.inv()
            computePanelPos()
        }
        try { wm?.updateViewLayout(p, panelLp) } catch (_: Exception) {}
    }

    private fun endTyping() {
        val et = ttsEt
        if (et != null) {
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(et.windowToken, 0)
            } catch (_: Exception) {}
            et.clearFocus()
        }
        setPanelFocusable(false)
    }

    private fun sendTts(et: EditText) {
        val t = et.text.toString()
        if (t.isBlank()) { ttsStatus?.text = "আগে কিছু লেখো"; return }
        ttsStatus?.text = "⏳ ভয়েস বানানো হচ্ছে..."
        endTyping()
        Tts.speak(this, t) { err ->
            if (err != null) {
                ttsStatus?.text = "❌ $err"
                Toast.makeText(this, err, Toast.LENGTH_LONG).show()
            } else {
                ttsStatus?.text = if (InjectCtl.active) "✅ মাইকে পাঠানো হচ্ছে" else "✅ বাজছে (স্পিকারে)"
            }
        }
    }

    private fun movePanelBy(dx: Int, dy: Int) {
        val p = panel ?: return
        val b = bubble ?: return
        val nx = (panelLp.x + dx).coerceIn(0, maxOf(0, sw() - panelLp.width))
        val ny = (panelLp.y + dy).coerceIn(0, maxOf(0, sh() - panelLp.height))
        val ddx = nx - panelLp.x
        val ddy = ny - panelLp.y
        panelLp.x = nx
        panelLp.y = ny
        bubbleLp.x += ddx
        bubbleLp.y = (bubbleLp.y + ddy).coerceIn(0, maxOf(0, sh() - bubbleLp.height))
        try { wm?.updateViewLayout(p, panelLp) } catch (_: Exception) {}
        try { wm?.updateViewLayout(b, bubbleLp) } catch (_: Exception) {}
    }

    private fun refreshInjectChip() {
        val c = injectChip ?: return
        val on = InjectCtl.active
        c.text = if (on) "🎙 Inject ON ✅" else "🎙 Inject OFF"
        c.background = if (on) Ui.rect(0xFF0E7A55.toInt(), dp(10), Ui.GREEN, dp(1))
        else Ui.rect(0xFF14246B.toInt(), dp(10), 0x663A55C0, dp(1))
    }

    private fun toggleInject() {
        if (injectBusy) return
        injectBusy = true
        val turnOn = !InjectCtl.active
        if (!turnOn) Player.stop()
        injectChip?.text = if (turnOn) "⏳ চালু হচ্ছে..." else "⏳ বন্ধ হচ্ছে..."
        Thread {
            val msg = if (turnOn) {
                if (RootTools.hasRoot()) InjectCtl.start(this) else "Root নেই ❌"
            } else {
                InjectCtl.stop(this)
                "ইনজেকশন বন্ধ"
            }
            handler.post {
                injectBusy = false
                refreshInjectChip()
                Toast.makeText(this, msg.lines().first(), Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun computePanelPos() {
        val bs = bubbleLp.width
        val pw = panelLp.width
        val ph = panelLp.height
        if (typing) {
            panelLp.x = (bubbleLp.x + bs / 2 - pw / 2).coerceIn(dp(4), maxOf(dp(4), sw() - pw - dp(4)))
            panelLp.y = dp(8)
            return
        }
        if (ph + bs + dp(12) > sh()) {
            // উঁচু প্যানেল (ল্যান্ডস্কেপ): বাবলের পাশে বসাও, যাতে বাবল ঢেকে না যায়
            val bubbleLeft = bubbleLp.x + bs / 2 < sw() / 2
            val x = if (bubbleLeft) bubbleLp.x + bs + dp(6) else bubbleLp.x - pw - dp(6)
            panelLp.x = x.coerceIn(dp(4), maxOf(dp(4), sw() - pw - dp(4)))
            panelLp.y = ((sh() - ph) / 2).coerceAtLeast(dp(4))
            return
        }
        val x = bubbleLp.x + bs / 2 - pw / 2
        panelLp.x = x.coerceIn(dp(4), maxOf(dp(4), sw() - pw - dp(4)))
        var y = bubbleLp.y + bs + dp(6)
        if (y + ph > sh() - dp(12)) y = maxOf(dp(8), bubbleLp.y - ph - dp(6))
        panelLp.y = y
    }

    private fun layoutPanel() {
        val p = panel ?: return
        computePanelPos()
        try { wm?.updateViewLayout(p, panelLp) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Player.removeListener(playListener)
        try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        panel = null
        bubble = null
        cards.clear()
        val wasRunning = running
        running = false
        Player.stop()
        if (wasRunning) onState?.invoke(false)
        super.onDestroy()
    }
}
