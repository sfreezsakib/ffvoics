package com.issakib.isffvoice

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min

object Ui {
    val BG0 = 0xFF040A28.toInt()
    val BG1 = 0xFF0A1448.toInt()
    val BG2 = 0xFF1A0B3D.toInt()
    val CARD = 0xFF0D1A5A.toInt()
    val CYAN = 0xFF22E5FF.toInt()
    val PURPLE = 0xFF9B5CFF.toInt()
    val GREEN = 0xFF14C98A.toInt()
    val RED = 0xFFFF3B5C.toInt()
    val MUTED = 0xFF8FA3D6.toInt()
    val IDLE_STROKE = 0x663A55C0

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rect(color: Int, radius: Int, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    fun oval(color: Int, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    fun grad(
        c1: Int, c2: Int, radius: Int,
        orient: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
    ): GradientDrawable = GradientDrawable(orient, intArrayOf(c1, c2)).apply {
        cornerRadius = radius.toFloat()
    }

    /** r < 0 হলে গোল (circle) */
    fun clipRound(v: View, r: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val rr = if (r < 0) min(view.width, view.height) / 2f else r
                outline.setRoundRect(0, 0, view.width, view.height, rr)
            }
        }
        v.clipToOutline = true
    }

    @SuppressLint("ClickableViewAccessibility")
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    fun popIn(v: View, delay: Long) {
        v.alpha = 0f
        v.translationY = v.resources.displayMetrics.density * 18f
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(300)
            .setInterpolator(OvershootInterpolator(0.9f)).start()
    }

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun bitmap(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        val b = try { BitmapFactory.decodeFile(path) } catch (e: Exception) { null } ?: return null
        cache.put(path, b)
        return b
    }

    fun button(ctx: Context, label: String, c1: Int, c2: Int, sp: Float = 14f, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = sp
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12))
            background = grad(c1, c2, dp(ctx, 14))
            isClickable = true
            setOnClickListener { onClick() }
            pressable(this)
        }

    /** চলমান নিয়ন গ্রেডিয়েন্ট টেক্সট */
    fun neonTitle(tv: TextView): ValueAnimator {
        val w = dp(tv.context, 240).toFloat()
        val shader = LinearGradient(
            0f, 0f, w, 0f, intArrayOf(CYAN, PURPLE, CYAN), null, Shader.TileMode.MIRROR
        )
        tv.paint.shader = shader
        return ValueAnimator.ofFloat(0f, w * 2).apply {
            duration = 3500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val m = Matrix()
                m.setTranslate(it.animatedValue as Float, 0f)
                shader.setLocalMatrix(m)
                tv.invalidate()
            }
            start()
        }
    }

    fun pulse(v: View, from: Float, to: Float, ms: Long): ValueAnimator =
        ValueAnimator.ofFloat(from, to).apply {
            duration = ms
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener {
                val s = it.animatedValue as Float
                v.scaleX = s
                v.scaleY = s
            }
            start()
        }

    fun dialog(ctx: Context, content: View): Dialog {
        val d = Dialog(ctx)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        content.background = rect(0xFF0B1550.toInt(), dp(ctx, 22), CYAN, dp(ctx, 1))
        content.setPadding(dp(ctx, 18), dp(ctx, 18), dp(ctx, 18), dp(ctx, 18))
        d.setContentView(content)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((ctx.resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        content.scaleX = 0.88f
        content.scaleY = 0.88f
        content.alpha = 0f
        content.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
        return d
    }

    fun title(ctx: Context, t: String): TextView = TextView(ctx).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, dp(ctx, 12))
    }

    fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
}

/** ভয়েস কার্ড: ছবি + নাম + প্লে ব্যাজ। বাজার সময় নিয়ন বর্ডার জ্বলে। */
class SoundCard(ctx: Context, val sound: Sound, side: Int, compact: Boolean) : LinearLayout(ctx) {
    private val bg = Ui.rect(Ui.CARD, Ui.dp(ctx, if (compact) 12 else 18), Ui.IDLE_STROKE, Ui.dp(ctx, 1))
    private val badge: TextView
    private var anim: ValueAnimator? = null
    private var playing = false
    private val strokeW = Ui.dp(ctx, 2)
    private val idleW = Ui.dp(ctx, 1)

    init {
        orientation = VERTICAL
        val pad = Ui.dp(ctx, if (compact) 4 else 6)
        setPadding(pad, pad, pad, pad)
        background = bg
        val imgSize = side - pad * 2

        val holder = FrameLayout(ctx)
        Ui.clipRound(holder, Ui.dp(ctx, if (compact) 9 else 13).toFloat())
        val bmp = if (sound.img.isNotEmpty()) Ui.bitmap(sound.img) else null
        if (bmp != null) {
            holder.addView(
                ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageBitmap(bmp)
                },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        } else {
            val first = sound.name.trim().take(1).uppercase().ifEmpty { "🎙" }
            holder.addView(
                TextView(ctx).apply {
                    text = first
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    textSize = if (compact) 24f else 38f
                    typeface = Typeface.DEFAULT_BOLD
                    background = Ui.grad(Ui.PURPLE, Ui.CYAN, 0, GradientDrawable.Orientation.TL_BR)
                },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }

        badge = TextView(ctx).apply {
            text = "▶"
            textSize = if (compact) 9f else 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = Ui.oval(0xCC040A28.toInt(), Ui.CYAN, Ui.dp(ctx, 1))
        }
        val bs = Ui.dp(ctx, if (compact) 20 else 28)
        val bm = Ui.dp(ctx, 4)
        holder.addView(
            badge,
            FrameLayout.LayoutParams(bs, bs, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, bm, bm) }
        )
        addView(holder, LinearLayout.LayoutParams(imgSize, imgSize))

        addView(
            TextView(ctx).apply {
                text = sound.name
                setTextColor(Color.WHITE)
                textSize = if (compact) 10f else 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setLines(if (compact) 1 else 2)
                ellipsize = android.text.TextUtils.TruncateAt.END
            },
            LinearLayout.LayoutParams(imgSize, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = Ui.dp(ctx, 4)
            }
        )
        isClickable = true
        Ui.pressable(this)
    }

    fun setPlaying(p: Boolean) {
        if (p == playing) return
        playing = p
        anim?.cancel()
        anim = null
        badge.text = if (p) "■" else "▶"
        if (p) {
            anim = ValueAnimator.ofFloat(0.3f, 1f).apply {
                duration = 600
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                addUpdateListener {
                    val a = ((it.animatedValue as Float) * 255).toInt()
                    bg.setStroke(strokeW, Color.argb(a, 34, 229, 255))
                }
                start()
            }
        } else {
            bg.setStroke(idleW, Ui.IDLE_STROKE)
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}
